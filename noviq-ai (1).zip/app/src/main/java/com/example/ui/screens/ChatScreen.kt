package com.example.ui.screens

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.local.ChatMessageEntity
import com.example.data.repository.GenerationState
import com.example.service.SpeechState
import com.example.service.TtsState
import com.example.ui.theme.NoviqBackground
import com.example.ui.theme.NoviqCyan
import com.example.ui.theme.NoviqCyanDim
import com.example.ui.theme.NoviqError
import com.example.ui.theme.NoviqSurface
import com.example.ui.theme.NoviqSurfaceBorder
import com.example.ui.theme.NoviqSurfaceVariant
import com.example.ui.theme.NoviqTextPrimary
import com.example.ui.theme.NoviqTextSecondary
import com.example.ui.theme.NoviqViolet
import com.example.ui.viewmodels.ChatViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    viewModel: ChatViewModel,
    initialPrompt: String? = null
) {
    val context = LocalContext.current
    val currentMessages by viewModel.currentMessages.collectAsState()
    val allSessions by viewModel.allSessions.collectAsState()
    val currentSessionId by viewModel.currentSessionId.collectAsState()
    val generationState by viewModel.generationState.collectAsState()
    val speechState by viewModel.speechState.collectAsState()
    val ttsState by viewModel.ttsState.collectAsState()
    val promptText by viewModel.promptText.collectAsState()
    val selectedVoiceLanguage by viewModel.selectedVoiceLanguage.collectAsState()

    var showHistorySheet by remember { mutableStateOf(false) }
    var micPermissionGranted by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
        )
    }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        micPermissionGranted = isGranted
        if (isGranted) {
            viewModel.startListening()
        } else {
            Toast.makeText(context, "Microphone permission is required for voice input", Toast.LENGTH_SHORT).show()
        }
    }

    // Process initial prompt if passed
    LaunchedEffect(initialPrompt) {
        if (!initialPrompt.isNullOrBlank()) {
            viewModel.promptText.value = initialPrompt
            viewModel.sendCurrentPrompt()
        }
    }

    val listState = rememberLazyListState()
    LaunchedEffect(currentMessages.size) {
        if (currentMessages.isNotEmpty()) {
            listState.animateScrollToItem(currentMessages.size - 1)
        }
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .testTag("chat_screen"),
        containerColor = NoviqBackground,
        topBar = {
            // Chat Header
            Surface(
                color = NoviqSurface,
                border = androidx.compose.foundation.BorderStroke(1.dp, NoviqSurfaceBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Noviq Chat",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = NoviqTextPrimary
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(NoviqCyan.copy(alpha = 0.15f))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "Gemini 3.5",
                                    fontSize = 10.sp,
                                    color = NoviqCyan,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                        Text(
                            text = "Supports English, हिन्दी & Hinglish",
                            fontSize = 11.sp,
                            color = NoviqTextSecondary
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        IconButton(
                            onClick = { showHistorySheet = true },
                            modifier = Modifier.testTag("chat_history_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.History,
                                contentDescription = "Chat History",
                                tint = NoviqTextSecondary
                            )
                        }

                        IconButton(
                            onClick = { viewModel.startNewChat() },
                            modifier = Modifier.testTag("new_chat_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = "New Chat",
                                tint = NoviqCyan
                            )
                        }
                    }
                }
            }
        },
        bottomBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(NoviqSurface)
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                // Speech State Indicator Banner
                AnimatedVisibility(visible = speechState is SpeechState.Listening) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(NoviqCyan.copy(alpha = 0.2f))
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(
                                strokeWidth = 2.dp,
                                modifier = Modifier.size(16.dp),
                                color = NoviqCyan
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Listening (${if (selectedVoiceLanguage == "hi-IN") "हिन्दी" else "English/Hinglish"})... Speak now",
                                fontSize = 12.sp,
                                color = NoviqCyan,
                                fontWeight = FontWeight.Medium
                            )
                        }

                        TextButton(
                            onClick = { viewModel.stopListening() },
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Text("Done", color = NoviqCyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                // Generating / Stop Generation bar
                AnimatedVisibility(visible = generationState is GenerationState.Generating) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Button(
                            onClick = { viewModel.stopGeneration() },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = NoviqError.copy(alpha = 0.2f),
                                contentColor = NoviqError
                            ),
                            shape = RoundedCornerShape(20.dp),
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("stop_generation_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Stop,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Stop Generation", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                // Input Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Voice Language Toggle (English vs Hindi)
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = NoviqSurfaceVariant,
                        modifier = Modifier.clickable {
                            val nextLang = if (selectedVoiceLanguage == "en-IN") "hi-IN" else "en-IN"
                            viewModel.selectedVoiceLanguage.value = nextLang
                        }
                    ) {
                        Text(
                            text = if (selectedVoiceLanguage == "hi-IN") "HI" else "EN",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = NoviqCyan,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 12.dp)
                        )
                    }

                    // Microphone Button
                    IconButton(
                        onClick = {
                            if (speechState is SpeechState.Listening) {
                                viewModel.stopListening()
                            } else {
                                if (micPermissionGranted) {
                                    viewModel.startListening()
                                } else {
                                    micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                }
                            }
                        },
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(
                                if (speechState is SpeechState.Listening) NoviqCyan
                                else NoviqSurfaceVariant
                            )
                            .testTag("chat_mic_button")
                    ) {
                        Icon(
                            imageVector = if (speechState is SpeechState.Listening) Icons.Default.Stop else Icons.Default.Mic,
                            contentDescription = "Microphone",
                            tint = if (speechState is SpeechState.Listening) Color.Black else NoviqTextPrimary
                        )
                    }

                    // Text Field
                    OutlinedTextField(
                        value = promptText,
                        onValueChange = { viewModel.promptText.value = it },
                        placeholder = { Text("Ask in Hindi, English, Hinglish...", fontSize = 13.sp, color = NoviqTextSecondary) },
                        maxLines = 4,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NoviqCyan,
                            unfocusedBorderColor = NoviqSurfaceBorder,
                            focusedTextColor = NoviqTextPrimary,
                            unfocusedTextColor = NoviqTextPrimary,
                            focusedContainerColor = NoviqSurfaceVariant,
                            unfocusedContainerColor = NoviqSurfaceVariant
                        ),
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("chat_input_field")
                    )

                    // Send Button
                    IconButton(
                        onClick = { viewModel.sendCurrentPrompt() },
                        enabled = promptText.isNotBlank() && generationState !is GenerationState.Generating,
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(
                                if (promptText.isNotBlank() && generationState !is GenerationState.Generating) NoviqCyan
                                else NoviqSurfaceVariant
                            )
                            .testTag("chat_send_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Send,
                            contentDescription = "Send",
                            tint = if (promptText.isNotBlank()) Color.Black else NoviqTextSecondary
                        )
                    }
                }
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            if (currentMessages.isEmpty()) {
                // Empty state greeting
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .clip(CircleShape)
                            .background(NoviqCyan.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = NoviqCyan,
                            modifier = Modifier.size(32.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "How can Noviq AI assist you today?",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = NoviqTextPrimary
                    )

                    Text(
                        text = "Ask questions, brainstorm ideas, write content or translate in English, हिन्दी, or Hinglish.",
                        fontSize = 13.sp,
                        color = NoviqTextSecondary,
                        modifier = Modifier.padding(top = 8.dp, start = 16.dp, end = 16.dp),
                        lineHeight = 18.sp
                    )
                }
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    items(currentMessages) { message ->
                        ChatMessageBubble(
                            message = message,
                            ttsState = ttsState,
                            onCopy = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                val clip = ClipData.newPlainText("Noviq AI", message.content)
                                clipboard.setPrimaryClip(clip)
                                Toast.makeText(context, "Copied to clipboard", Toast.LENGTH_SHORT).show()
                            },
                            onShare = {
                                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_TEXT, message.content)
                                }
                                context.startActivity(Intent.createChooser(shareIntent, "Share Noviq AI Response"))
                            },
                            onSpeak = {
                                viewModel.speakResponse(message.id, message.content)
                            },
                            onPauseSpeak = {
                                viewModel.pauseTts()
                            },
                            onResumeSpeak = {
                                viewModel.resumeTts()
                            },
                            onStopSpeak = {
                                viewModel.stopTts()
                            },
                            onRetry = {
                                viewModel.retryLastMessage()
                            }
                        )
                    }

                    if (generationState is GenerationState.Generating) {
                        item {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(start = 8.dp)
                            ) {
                                CircularProgressIndicator(
                                    strokeWidth = 2.dp,
                                    modifier = Modifier.size(18.dp),
                                    color = NoviqCyan
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = "Noviq AI is thinking...",
                                    fontSize = 13.sp,
                                    color = NoviqCyan
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // History Bottom Sheet
    if (showHistorySheet) {
        ModalBottomSheet(
            onDismissRequest = { showHistorySheet = false },
            sheetState = rememberModalBottomSheetState(),
            containerColor = NoviqSurface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Chat History",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = NoviqTextPrimary
                    )

                    TextButton(onClick = {
                        viewModel.clearAllChats()
                        showHistorySheet = false
                    }) {
                        Text("Clear All", color = NoviqError, fontSize = 13.sp)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                if (allSessions.isEmpty()) {
                    Text(
                        text = "No saved conversations yet.",
                        color = NoviqTextSecondary,
                        fontSize = 14.sp,
                        modifier = Modifier.padding(vertical = 20.dp)
                    )
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(300.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(allSessions) { session ->
                            val isSelected = session.id == currentSessionId
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = if (isSelected) NoviqCyan.copy(alpha = 0.15f) else NoviqSurfaceVariant,
                                border = if (isSelected) androidx.compose.foundation.BorderStroke(1.dp, NoviqCyan) else null,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        viewModel.selectSession(session.id)
                                        showHistorySheet = false
                                    }
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = session.title,
                                            fontWeight = FontWeight.SemiBold,
                                            fontSize = 14.sp,
                                            color = NoviqTextPrimary,
                                            maxLines = 1
                                        )
                                    }

                                    IconButton(
                                        onClick = { viewModel.deleteSession(session.id) },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Delete,
                                            contentDescription = "Delete chat",
                                            tint = NoviqTextSecondary,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ChatMessageBubble(
    message: ChatMessageEntity,
    ttsState: TtsState,
    onCopy: () -> Unit,
    onShare: () -> Unit,
    onSpeak: () -> Unit,
    onPauseSpeak: () -> Unit,
    onResumeSpeak: () -> Unit,
    onStopSpeak: () -> Unit,
    onRetry: () -> Unit
) {
    val isUser = message.role == "user"
    val isSpeaking = (ttsState as? TtsState.Speaking)?.messageId == message.id
    val isPaused = (ttsState as? TtsState.Paused)?.messageId == message.id

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
    ) {
        Surface(
            shape = RoundedCornerShape(
                topStart = 16.dp,
                topEnd = 16.dp,
                bottomStart = if (isUser) 16.dp else 4.dp,
                bottomEnd = if (isUser) 4.dp else 16.dp
            ),
            color = if (isUser) NoviqCyanDim else NoviqSurface,
            border = if (!isUser) androidx.compose.foundation.BorderStroke(1.dp, NoviqSurfaceBorder) else null,
            modifier = Modifier.widthIn(max = 320.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = message.content,
                    fontSize = 14.sp,
                    color = if (isUser) Color.White else NoviqTextPrimary,
                    lineHeight = 20.sp
                )

                if (message.status == "ERROR") {
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = onRetry,
                        colors = ButtonDefaults.buttonColors(containerColor = NoviqError),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier.height(30.dp)
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Retry", fontSize = 11.sp)
                    }
                }
            }
        }

        // Action Toolbar for AI responses
        if (!isUser && message.status != "ERROR") {
            Row(
                modifier = Modifier.padding(top = 4.dp, start = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Speaker / TTS Button
                IconButton(
                    onClick = {
                        when {
                            isSpeaking -> onPauseSpeak()
                            isPaused -> onResumeSpeak()
                            else -> onSpeak()
                        }
                    },
                    modifier = Modifier
                        .size(32.dp)
                        .testTag("tts_play_pause_button_${message.id}")
                ) {
                    Icon(
                        imageVector = when {
                            isSpeaking -> Icons.Default.Pause
                            isPaused -> Icons.Default.PlayArrow
                            else -> Icons.AutoMirrored.Filled.VolumeUp
                        },
                        contentDescription = "Read aloud",
                        tint = if (isSpeaking || isPaused) NoviqCyan else NoviqTextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                }

                if (isSpeaking || isPaused) {
                    IconButton(
                        onClick = onStopSpeak,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Stop,
                            contentDescription = "Stop speech",
                            tint = NoviqError,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                // Copy Button
                IconButton(
                    onClick = onCopy,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ContentCopy,
                        contentDescription = "Copy text",
                        tint = NoviqTextSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                }

                // Share Button
                IconButton(
                    onClick = onShare,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Share,
                        contentDescription = "Share",
                        tint = NoviqTextSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}
