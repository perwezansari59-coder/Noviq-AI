package com.example.data.repository

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class UserUsage(
    val chatUsed: Int,
    val chatMax: Int,
    val docUsed: Int,
    val docMax: Int,
    val photoUsed: Int,
    val photoMax: Int,
    val isPremium: Boolean
) {
    val chatRemaining: Int get() = if (isPremium) 9999 else (chatMax - chatUsed).coerceAtLeast(0)
    val docRemaining: Int get() = if (isPremium) 9999 else (docMax - docUsed).coerceAtLeast(0)
    val photoRemaining: Int get() = if (isPremium) 9999 else (photoMax - photoUsed).coerceAtLeast(0)
    val canChat: Boolean get() = isPremium || chatRemaining > 0
    val canDoc: Boolean get() = isPremium || docRemaining > 0
    val canPhoto: Boolean get() = isPremium || photoRemaining > 0
}

class UsageManager(private val context: Context, private val billingRepo: BillingRepository) {
    private val prefs = context.getSharedPreferences("noviq_usage_prefs", Context.MODE_PRIVATE)

    companion object {
        const val FREE_CHAT_LIMIT = 20
        const val FREE_DOC_LIMIT = 5
        const val FREE_PHOTO_LIMIT = 10
    }

    private val dateFormat = SimpleDateFormat("yyyyMMdd", Locale.US)
    private val todayKey: String get() = dateFormat.format(Date())

    private val _usage = MutableStateFlow(loadUsage())
    val usage: StateFlow<UserUsage> = _usage

    private fun loadUsage(): UserUsage {
        val lastDate = prefs.getString("last_usage_date", "")
        val today = todayKey
        if (lastDate != today) {
            // New day: reset daily usage
            prefs.edit()
                .putString("last_usage_date", today)
                .putInt("daily_chat", 0)
                .putInt("daily_doc", 0)
                .putInt("daily_photo", 0)
                .apply()
        }

        val chat = prefs.getInt("daily_chat", 0)
        val doc = prefs.getInt("daily_doc", 0)
        val photo = prefs.getInt("daily_photo", 0)
        val isPrem = billingRepo.isPremium.value

        return UserUsage(
            chatUsed = chat,
            chatMax = FREE_CHAT_LIMIT,
            docUsed = doc,
            docMax = FREE_DOC_LIMIT,
            photoUsed = photo,
            photoMax = FREE_PHOTO_LIMIT,
            isPremium = isPrem
        )
    }

    fun recordChatQuery(): Boolean {
        refresh()
        if (!_usage.value.canChat) return false
        val newChat = _usage.value.chatUsed + 1
        prefs.edit().putInt("daily_chat", newChat).apply()
        refresh()
        return true
    }

    fun recordDocQuery(): Boolean {
        refresh()
        if (!_usage.value.canDoc) return false
        val newDoc = _usage.value.docUsed + 1
        prefs.edit().putInt("daily_doc", newDoc).apply()
        refresh()
        return true
    }

    fun recordPhotoEdit(): Boolean {
        refresh()
        if (!_usage.value.canPhoto) return false
        val newPhoto = _usage.value.photoUsed + 1
        prefs.edit().putInt("daily_photo", newPhoto).apply()
        refresh()
        return true
    }

    fun refresh() {
        _usage.value = loadUsage()
    }
}
