package com.example.data.repository

import com.example.BuildConfig
import com.example.data.api.GeminiApiClient
import com.example.data.api.GeminiContent
import com.example.data.api.GeminiGenerationConfig
import com.example.data.api.GeminiPart
import com.example.data.api.GenerateContentRequest
import com.example.data.local.ChatDao
import com.example.data.local.ChatMessageEntity
import com.example.data.local.ChatSessionEntity
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

sealed class GenerationState {
    object Idle : GenerationState()
    object Generating : GenerationState()
    data class Error(val message: String) : GenerationState()
}

class GeminiChatRepository(
    private val chatDao: ChatDao,
    private val usageManager: UsageManager
) {
    private val _generationState = MutableStateFlow<GenerationState>(GenerationState.Idle)
    val generationState: StateFlow<GenerationState> = _generationState

    private var activeJob: Job? = null

    val allSessions: Flow<List<ChatSessionEntity>> = chatDao.getAllSessions()

    fun getMessagesForSession(sessionId: String): Flow<List<ChatMessageEntity>> {
        return chatDao.getMessagesForSession(sessionId)
    }

    suspend fun createNewSession(userId: String = "local_user"): String = withContext(Dispatchers.IO) {
        val newId = UUID.randomUUID().toString()
        val now = System.currentTimeMillis()
        val session = ChatSessionEntity(
            id = newId,
            title = "New Chat",
            createdAt = now,
            updatedAt = now,
            userId = userId
        )
        chatDao.insertSession(session)
        newId
    }

    suspend fun deleteSession(sessionId: String) = withContext(Dispatchers.IO) {
        chatDao.deleteMessagesForSession(sessionId)
        chatDao.deleteSession(sessionId)
    }

    suspend fun clearAllChats() = withContext(Dispatchers.IO) {
        chatDao.deleteAllMessages()
        chatDao.deleteAllSessions()
    }

    fun stopGeneration() {
        activeJob?.cancel(CancellationException("User stopped generation."))
        activeJob = null
        _generationState.value = GenerationState.Idle
    }

    fun sendMessage(
        scope: CoroutineScope,
        sessionId: String,
        userPrompt: String,
        existingMessages: List<ChatMessageEntity>
    ) {
        if (userPrompt.isBlank()) return

        // 1. Check Usage Limits
        if (!usageManager.recordChatQuery()) {
            _generationState.value = GenerationState.Error(
                "Daily Free message limit reached (${UsageManager.FREE_CHAT_LIMIT}/${UsageManager.FREE_CHAT_LIMIT}). Upgrade to Noviq AI Premium for unlimited conversations."
            )
            return
        }

        // 2. Check API Key
        val apiKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Throwable) {
            ""
        }

        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            _generationState.value = GenerationState.Error(
                "Gemini API key is not configured. Please add your GEMINI_API_KEY in the AI Studio Secrets panel."
            )
            return
        }

        activeJob?.cancel()
        activeJob = scope.launch(Dispatchers.IO) {
            _generationState.value = GenerationState.Generating

            val now = System.currentTimeMillis()
            val userMsgId = UUID.randomUUID().toString()
            val assistantMsgId = UUID.randomUUID().toString()

            // Save user message to database
            chatDao.insertMessage(
                ChatMessageEntity(
                    id = userMsgId,
                    sessionId = sessionId,
                    role = "user",
                    content = userPrompt.trim(),
                    timestamp = now,
                    status = "SUCCESS"
                )
            )

            // Update session title if first message
            val session = chatDao.getSessionById(sessionId)
            if (session != null && (session.title == "New Chat" || session.title.isBlank())) {
                val title = if (userPrompt.length > 30) userPrompt.take(30) + "..." else userPrompt
                chatDao.updateSession(session.copy(title = title, updatedAt = now))
            } else if (session != null) {
                chatDao.updateSession(session.copy(updatedAt = now))
            }

            // Prepare prompt history for Gemini
            val contentsList = mutableListOf<GeminiContent>()
            for (msg in existingMessages.takeLast(10)) {
                val role = if (msg.role == "user") "user" else "model"
                contentsList.add(
                    GeminiContent(
                        role = role,
                        parts = listOf(GeminiPart(text = msg.content))
                    )
                )
            }
            // Add current message
            contentsList.add(
                GeminiContent(
                    role = "user",
                    parts = listOf(GeminiPart(text = userPrompt.trim()))
                )
            )

            val systemInstruction = GeminiContent(
                parts = listOf(
                    GeminiPart(
                        text = "You are Noviq AI, an intelligent, helpful, and concise AI assistant. " +
                               "You have native fluent support for English, Hindi, and Hinglish. " +
                               "Always respond helpfully and naturally in the language or dialect used by the user. " +
                               "Format responses cleanly with markdown where helpful."
                    )
                )
            )

            val request = GenerateContentRequest(
                contents = contentsList,
                systemInstruction = systemInstruction,
                generationConfig = GeminiGenerationConfig(
                    temperature = 0.7f,
                    topP = 0.95f,
                    topK = 40,
                    maxOutputTokens = 2048
                )
            )

            try {
                val response = GeminiApiClient.apiService.generateContent(apiKey, request)
                val responseText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                    ?: response.error?.message
                    ?: "I am sorry, I could not generate a response. Please try again."

                chatDao.insertMessage(
                    ChatMessageEntity(
                        id = assistantMsgId,
                        sessionId = sessionId,
                        role = "model",
                        content = responseText.trim(),
                        timestamp = System.currentTimeMillis(),
                        status = "SUCCESS"
                    )
                )
                _generationState.value = GenerationState.Idle
            } catch (e: CancellationException) {
                // User clicked "Stop Generation"
                chatDao.insertMessage(
                    ChatMessageEntity(
                        id = assistantMsgId,
                        sessionId = sessionId,
                        role = "model",
                        content = "[Generation stopped by user]",
                        timestamp = System.currentTimeMillis(),
                        status = "STOPPED"
                    )
                )
                _generationState.value = GenerationState.Idle
            } catch (e: Exception) {
                val errorText = "Request failed: ${e.localizedMessage ?: "Unknown error"}. Check internet connection or API limits."
                chatDao.insertMessage(
                    ChatMessageEntity(
                        id = assistantMsgId,
                        sessionId = sessionId,
                        role = "model",
                        content = errorText,
                        timestamp = System.currentTimeMillis(),
                        status = "ERROR"
                    )
                )
                _generationState.value = GenerationState.Error(errorText)
            }
        }
    }

    suspend fun retryMessage(
        scope: CoroutineScope,
        sessionId: String,
        lastUserMessage: String,
        existingMessages: List<ChatMessageEntity>
    ) {
        sendMessage(scope, sessionId, lastUserMessage, existingMessages)
    }
}
