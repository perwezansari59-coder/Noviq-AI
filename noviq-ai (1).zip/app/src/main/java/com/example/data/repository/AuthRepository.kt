package com.example.data.repository

import android.content.Context
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.tasks.await

data class AuthUserState(
    val isLoggedIn: Boolean = false,
    val uid: String = "",
    val email: String = "",
    val displayName: String = "",
    val isDemoUser: Boolean = false
)

sealed class AuthResult {
    data class Success(val user: AuthUserState) : AuthResult()
    data class Error(val message: String) : AuthResult()
}

class AuthRepository(private val context: Context) {
    private val prefs = context.getSharedPreferences("noviq_auth_prefs", Context.MODE_PRIVATE)

    private val isFirebaseAvailable: Boolean
        get() {
            return try {
                FirebaseApp.getApps(context).isNotEmpty()
            } catch (e: Exception) {
                false
            }
        }

    private val firebaseAuth: FirebaseAuth?
        get() {
            return if (isFirebaseAvailable) {
                try {
                    FirebaseAuth.getInstance()
                } catch (e: Exception) {
                    null
                }
            } else null
        }

    private val _currentUser = MutableStateFlow(loadInitialUser())
    val currentUser: StateFlow<AuthUserState> = _currentUser

    private fun loadInitialUser(): AuthUserState {
        val fbUser = firebaseAuth?.currentUser
        if (fbUser != null) {
            return AuthUserState(
                isLoggedIn = true,
                uid = fbUser.uid,
                email = fbUser.email ?: "",
                displayName = fbUser.displayName ?: fbUser.email?.substringBefore("@") ?: "User",
                isDemoUser = false
            )
        }

        // Check local saved session
        val savedEmail = prefs.getString("user_email", null)
        val savedUid = prefs.getString("user_uid", null)
        val isDemo = prefs.getBoolean("is_demo", false)

        return if (savedEmail != null && savedUid != null) {
            AuthUserState(
                isLoggedIn = true,
                uid = savedUid,
                email = savedEmail,
                displayName = savedEmail.substringBefore("@"),
                isDemoUser = isDemo
            )
        } else {
            AuthUserState(isLoggedIn = false)
        }
    }

    suspend fun login(email: String, pass: String): AuthResult {
        if (email.isBlank() || pass.isBlank()) {
            return AuthResult.Error("Please enter both email and password.")
        }
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            return AuthResult.Error("Please enter a valid email address.")
        }
        if (pass.length < 6) {
            return AuthResult.Error("Password must be at least 6 characters.")
        }

        val auth = firebaseAuth
        if (auth != null) {
            return try {
                val result = auth.signInWithEmailAndPassword(email, pass).await()
                val user = result.user
                if (user != null) {
                    val state = AuthUserState(
                        isLoggedIn = true,
                        uid = user.uid,
                        email = user.email ?: email,
                        displayName = user.displayName ?: email.substringBefore("@"),
                        isDemoUser = false
                    )
                    saveSession(state)
                    _currentUser.value = state
                    AuthResult.Success(state)
                } else {
                    AuthResult.Error("Authentication returned empty user profile.")
                }
            } catch (e: Exception) {
                AuthResult.Error(e.localizedMessage ?: "Firebase login failed.")
            }
        }

        // If Firebase is not configured yet with google-services.json
        val demoState = AuthUserState(
            isLoggedIn = true,
            uid = "local_" + email.hashCode(),
            email = email,
            displayName = email.substringBefore("@"),
            isDemoUser = true
        )
        saveSession(demoState)
        _currentUser.value = demoState
        return AuthResult.Success(demoState)
    }

    suspend fun signup(email: String, pass: String): AuthResult {
        if (email.isBlank() || pass.isBlank()) {
            return AuthResult.Error("Please enter both email and password.")
        }
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            return AuthResult.Error("Please enter a valid email address.")
        }
        if (pass.length < 6) {
            return AuthResult.Error("Password must be at least 6 characters.")
        }

        val auth = firebaseAuth
        if (auth != null) {
            return try {
                val result = auth.createUserWithEmailAndPassword(email, pass).await()
                val user = result.user
                if (user != null) {
                    val state = AuthUserState(
                        isLoggedIn = true,
                        uid = user.uid,
                        email = user.email ?: email,
                        displayName = email.substringBefore("@"),
                        isDemoUser = false
                    )
                    saveSession(state)
                    _currentUser.value = state
                    AuthResult.Success(state)
                } else {
                    AuthResult.Error("Signup returned empty user profile.")
                }
            } catch (e: Exception) {
                AuthResult.Error(e.localizedMessage ?: "Firebase signup failed.")
            }
        }

        // Demo session if Firebase is not linked
        val demoState = AuthUserState(
            isLoggedIn = true,
            uid = "local_" + email.hashCode(),
            email = email,
            displayName = email.substringBefore("@"),
            isDemoUser = true
        )
        saveSession(demoState)
        _currentUser.value = demoState
        return AuthResult.Success(demoState)
    }

    fun logout() {
        try {
            firebaseAuth?.signOut()
        } catch (ignored: Exception) {}

        prefs.edit().clear().apply()
        _currentUser.value = AuthUserState(isLoggedIn = false)
    }

    private fun saveSession(state: AuthUserState) {
        prefs.edit()
            .putString("user_email", state.email)
            .putString("user_uid", state.uid)
            .putBoolean("is_demo", state.isDemoUser)
            .apply()
    }
}
