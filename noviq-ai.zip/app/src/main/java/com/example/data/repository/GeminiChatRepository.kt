package com.example.data.repository

import com.example.BuildConfig
import com.example.data.api.GeminiApiClient
import com.example.data.api.GeminiContent
import com.example.data.api.GeminiGenerationConfig
import com.example.data.api.GeminiPart
import com.example.data.api.GenerateContentRequest
import com.example.data.local.ChatDao
import com.example.data.local.ChatMessageEntity
import com.example.data.local.ChatSessionEntity
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

sealed class GenerationState {
    object Idle : GenerationState()
    object Generating : GenerationState()
    data class Error(val message: String) : GenerationState()
}

class GeminiChatRepository(
    private val chatDao: ChatDao,
    private val usageManager: UsageManager
) {
    private val _generationState = MutableStateFlow<GenerationState>(GenerationState.Idle)
    val generationState: StateFlow<GenerationState> = _generationState

    private var activeJob: Job? = null

    val allSessions: Flow<List<ChatSessionEntity>> = chatDao.getAllSessions()

    fun getMessagesForSession(sessionId: String): Flow<List<ChatMessageEntity>> {
        return chatDao.getMessagesForSession(sessionId)
    }

    suspend fun createNewSession(userId: String = "local_user"): String = withContext(Dispatchers.IO) {
        val newId = UUID.randomUUID().toString()
        val now = System.currentTimeMillis()
        val session = ChatSessionEntity(
            id = newId,
            title = "New Chat",
            createdAt = now,
            updatedAt = now,
            userId = userId
        )
        chatDao.insertSession(session)
        newId
    }

    suspend fun deleteSession(sessionId: String) = withContext(Dispatchers.IO) {
        chatDao.deleteMessagesForSession(sessionId)
        chatDao.deleteSession(sessionId)
    }

    suspend fun clearAllChats() = withContext(Dispatchers.IO) {
        chatDao.deleteAllMessages()
        chatDao.deleteAllSessions()
    }

    fun stopGeneration() {
        activeJob?.cancel(CancellationException("User stopped generation."))
        activeJob = null
        _generationState.value = GenerationState.Idle
    }

    fun sendMessage(
        scope: CoroutineScope,
        sessionId: String,
        userPrompt: String,
        isRetry: Boolean = false
    ) {
        val cleanPrompt = userPrompt.trim()
        if (cleanPrompt.isBlank()) return

        // Prevent duplicate requests while one response is being generated
        if (_generationState.value is GenerationState.Generating && activeJob?.isActive == true) {
            return
        }

        activeJob?.cancel()
        activeJob = scope.launch(Dispatchers.IO) {
            val now = System.currentTimeMillis()
            val userMsgId = UUID.randomUUID().toString()
            val assistantMsgId = UUID.randomUUID().toString()

            // 1. Immediately insert user message into database (if not a retry)
            if (!isRetry) {
                chatDao.insertMessage(
                    ChatMessageEntity(
                        id = userMsgId,
                        sessionId = sessionId,
                        role = "user",
                        content = cleanPrompt,
                        timestamp = now,
                        status = "SUCCESS"
                    )
                )

                // Update session title if first message
                val session = chatDao.getSessionById(sessionId)
                if (session != null && (session.title == "New Chat" || session.title.isBlank())) {
                    val title = if (cleanPrompt.length > 30) cleanPrompt.take(30) + "..." else cleanPrompt
                    chatDao.updateSession(session.copy(title = title, updatedAt = now))
                } else if (session != null) {
                    chatDao.updateSession(session.copy(updatedAt = now))
                }
            }

            // 2. Set generating state so UI typing/loading indicator appears immediately
            _generationState.value = GenerationState.Generating

            // 3. Check Usage Limits
            if (!usageManager.recordChatQuery()) {
                val limitError = "Daily Free message limit reached (${UsageManager.FREE_CHAT_LIMIT}/${UsageManager.FREE_CHAT_LIMIT}). Upgrade to Noviq AI Premium for unlimited conversations."
                chatDao.insertMessage(
                    ChatMessageEntity(
                        id = assistantMsgId,
                        sessionId = sessionId,
                        role = "model",
                        content = limitError,
                        timestamp = System.currentTimeMillis(),
                        status = "ERROR"
                    )
                )
                _generationState.value = GenerationState.Error(limitError)
                return@launch
            }

            // 4. Check API Key
            val apiKey = try {
                BuildConfig.GEMINI_API_KEY
            } catch (e: Throwable) {
                ""
            }

            if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
                val keyError = "Gemini API key is not configured. Please add your GEMINI_API_KEY in the AI Studio Secrets panel."
                chatDao.insertMessage(
                    ChatMessageEntity(
                        id = assistantMsgId,
                        sessionId = sessionId,
                        role = "model",
                        content = keyError,
                        timestamp = System.currentTimeMillis(),
                        status = "ERROR"
                    )
                )
                _generationState.value = GenerationState.Error(keyError)
                return@launch
            }

            // 5. Query previous messages for this session directly from DB
            val previousMessages = chatDao.getPreviousMessagesForSession(sessionId, userMsgId)
            val contentsList = mutableListOf<GeminiContent>()
            var lastRole: String? = null

            for (msg in previousMessages.takeLast(10)) {
                if (msg.status == "ERROR" || msg.content.isBlank()) continue
                val role = if (msg.role == "user") "user" else "model"
                if (role != lastRole) {
                    contentsList.add(
                        GeminiContent(
                            role = role,
                            parts = listOf(GeminiPart(text = msg.content.trim()))
                        )
                    )
                    lastRole = role
                }
            }

            // Ensure strictly alternating role ordering ending with the current user prompt
            if (lastRole == "user") {
                contentsList.removeAt(contentsList.size - 1)
            }
            contentsList.add(
                GeminiContent(
                    role = "user",
                    parts = listOf(GeminiPart(text = cleanPrompt))
                )
            )

            val systemInstruction = GeminiContent(
                parts = listOf(
                    GeminiPart(
                        text = "You are Noviq AI, an intelligent, helpful, and concise AI assistant. " +
                               "You have native fluent support for English, Hindi, and Hinglish. " +
                               "Always respond helpfully and naturally in the language or dialect used by the user. " +
                               "Format responses cleanly with markdown where helpful."
                    )
                )
            )

            val request = GenerateContentRequest(
                contents = contentsList,
                systemInstruction = systemInstruction,
                generationConfig = GeminiGenerationConfig(
                    temperature = 0.7f,
                    topP = 0.95f,
                    topK = 40,
                    maxOutputTokens = 2048
                )
            )

            try {
                val response = GeminiApiClient.apiService.generateContent(apiKey, request)
                val responseText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                    ?: response.error?.message
                    ?: "I am sorry, I could not generate a response. Please try again."

                val isApiError = response.candidates.isNullOrEmpty() && response.error != null

                chatDao.insertMessage(
                    ChatMessageEntity(
                        id = assistantMsgId,
                        sessionId = sessionId,
                        role = "model",
                        content = responseText.trim(),
                        timestamp = System.currentTimeMillis(),
                        status = if (isApiError) "ERROR" else "SUCCESS"
                    )
                )
                _generationState.value = if (isApiError) GenerationState.Error(responseText) else GenerationState.Idle
            } catch (e: CancellationException) {
                // User clicked "Stop Generation"
                chatDao.insertMessage(
                    ChatMessageEntity(
                        id = assistantMsgId,
                        sessionId = sessionId,
                        role = "model",
                        content = "[Generation stopped by user]",
                        timestamp = System.currentTimeMillis(),
                        status = "STOPPED"
                    )
                )
                _generationState.value = GenerationState.Idle
            } catch (e: Exception) {
                val errorMsg = when {
                    e.localizedMessage?.contains("Unable to resolve host", ignoreCase = true) == true ||
                    e is java.net.UnknownHostException ->
                        "Network error: Unable to connect to Gemini API. Please check your internet connection."
                    e.localizedMessage?.contains("timeout", ignoreCase = true) == true ||
                    e is java.net.SocketTimeoutException ->
                        "Network timeout: The request to Gemini API timed out. Please try again."
                    else -> "Request failed: ${e.localizedMessage ?: "Unknown error"}. Check internet connection or API key."
                }

                chatDao.insertMessage(
                    ChatMessageEntity(
                        id = assistantMsgId,
                        sessionId = sessionId,
                        role = "model",
                        content = errorMsg,
                        timestamp = System.currentTimeMillis(),
                        status = "ERROR"
                    )
                )
                _generationState.value = GenerationState.Error(errorMsg)
            }
        }
    }

    fun retryMessage(
        scope: CoroutineScope,
        sessionId: String,
        lastUserMessage: String
    ) {
        sendMessage(scope, sessionId, lastUserMessage, isRetry = true)
    }
}
