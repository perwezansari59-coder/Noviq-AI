package com.example.data.repository

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream

data class PhotoEditParams(
    val brightness: Float = 0f,    // -100f to +100f
    val contrast: Float = 1f,      // 0.5f to 2.0f
    val saturation: Float = 1f,    // 0.0f (grayscale) to 2.0f
    val rotation: Float = 0f,      // 0, 90, 180, 270
    val isEnhanced: Boolean = false,
    val isBlurred: Boolean = false,
    val isBackgroundRemoved: Boolean = false
)

sealed class PhotoSaveResult {
    data class Success(val uri: Uri, val message: String) : PhotoSaveResult()
    data class Error(val message: String) : PhotoSaveResult()
}

class PhotoEditorRepository(private val context: Context) {

    suspend fun loadBitmapFromUri(uri: Uri): Bitmap? = withContext(Dispatchers.IO) {
        try {
            context.contentResolver.openInputStream(uri)?.use { stream ->
                val options = BitmapFactory.Options().apply {
                    inJustDecodeBounds = true
                }
                // Check dimensions
                val bytes = stream.readBytes()
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options)

                val maxDimension = 1920
                var sampleSize = 1
                while (options.outWidth / sampleSize > maxDimension || options.outHeight / sampleSize > maxDimension) {
                    sampleSize *= 2
                }

                val decodeOptions = BitmapFactory.Options().apply {
                    inSampleSize = sampleSize
                }
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, decodeOptions)
            }
        } catch (e: Exception) {
            null
        }
    }

    suspend fun applyAdjustments(
        original: Bitmap,
        params: PhotoEditParams
    ): Bitmap = withContext(Dispatchers.Default) {
        var current = original

        // 1. Rotation if any
        if (params.rotation != 0f) {
            val matrix = Matrix().apply { postRotate(params.rotation) }
            current = Bitmap.createBitmap(current, 0, 0, current.width, current.height, matrix, true)
        }

        // 2. ColorMatrix for Brightness, Contrast, Saturation & Enhancement
        val cm = ColorMatrix()

        // Saturation
        val satMatrix = ColorMatrix()
        satMatrix.setSaturation(params.saturation)
        cm.postConcat(satMatrix)

        // Contrast & Brightness
        val scale = params.contrast * (if (params.isEnhanced) 1.15f else 1.0f)
        val translate = params.brightness + (if (params.isEnhanced) 10f else 0f)

        val contrastMatrix = ColorMatrix(floatArrayOf(
            scale, 0f, 0f, 0f, translate,
            0f, scale, 0f, 0f, translate,
            0f, 0f, scale, 0f, translate,
            0f, 0f, 0f, 1f, 0f
        ))
        cm.postConcat(contrastMatrix)

        val result = Bitmap.createBitmap(current.width, current.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(result)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            colorFilter = ColorMatrixColorFilter(cm)
        }
        canvas.drawBitmap(current, 0f, 0f, paint)

        // 3. Blur simulation if requested
        if (params.isBlurred) {
            val smallWidth = (result.width / 4).coerceAtLeast(1)
            val smallHeight = (result.height / 4).coerceAtLeast(1)
            val scaledDown = Bitmap.createScaledBitmap(result, smallWidth, smallHeight, true)
            return@withContext Bitmap.createScaledBitmap(scaledDown, result.width, result.height, true)
        }

        result
    }

    suspend fun cropBitmap(bitmap: Bitmap, aspectOption: String): Bitmap = withContext(Dispatchers.Default) {
        val w = bitmap.width
        val h = bitmap.height
        when (aspectOption) {
            "1:1" -> {
                val size = minOf(w, h)
                val x = (w - size) / 2
                val y = (h - size) / 2
                Bitmap.createBitmap(bitmap, x, y, size, size)
            }
            "4:3" -> {
                val targetW: Int
                val targetH: Int
                if (w.toFloat() / h > 4f / 3f) {
                    targetH = h
                    targetW = (h * 4f / 3f).toInt()
                } else {
                    targetW = w
                    targetH = (w * 3f / 4f).toInt()
                }
                val x = (w - targetW) / 2
                val y = (h - targetH) / 2
                Bitmap.createBitmap(bitmap, x, y, targetW, targetH)
            }
            "16:9" -> {
                val targetW: Int
                val targetH: Int
                if (w.toFloat() / h > 16f / 9f) {
                    targetH = h
                    targetW = (h * 16f / 9f).toInt()
                } else {
                    targetW = w
                    targetH = (w * 9f / 16f).toInt()
                }
                val x = (w - targetW) / 2
                val y = (h - targetH) / 2
                Bitmap.createBitmap(bitmap, x, y, targetW, targetH)
            }
            else -> bitmap
        }
    }

    suspend fun saveBitmapToGallery(bitmap: Bitmap): PhotoSaveResult = withContext(Dispatchers.IO) {
        val filename = "NoviqAI_${System.currentTimeMillis()}.png"
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, filename)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                    put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/NoviqAI")
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }

                val uri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                    ?: return@withContext PhotoSaveResult.Error("Could not create MediaStore entry.")

                context.contentResolver.openOutputStream(uri)?.use { out ->
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                }

                values.clear()
                values.put(MediaStore.Images.Media.IS_PENDING, 0)
                context.contentResolver.update(uri, values, null, null)

                PhotoSaveResult.Success(uri, "Saved to Pictures/NoviqAI")
            } else {
                val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "NoviqAI")
                if (!dir.exists()) dir.mkdirs()
                val file = File(dir, filename)
                FileOutputStream(file).use { out ->
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                }
                PhotoSaveResult.Success(Uri.fromFile(file), "Saved to Pictures/NoviqAI")
            }
        } catch (e: Exception) {
            PhotoSaveResult.Error("Failed to save image: ${e.localizedMessage}")
        }
    }

    suspend fun getShareUri(bitmap: Bitmap): Uri? = withContext(Dispatchers.IO) {
        try {
            val cachePath = File(context.cacheDir, "shared_images")
            cachePath.mkdirs()
            val file = File(cachePath, "noviq_shared_${System.currentTimeMillis()}.png")
            FileOutputStream(file).use { out ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
            }
            FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )
        } catch (e: Exception) {
            null
        }
    }
}
