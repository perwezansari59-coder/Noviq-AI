package com.example.data.local

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "chat_sessions")
data class ChatSessionEntity(
    @PrimaryKey
    val id: String,
    val title: String,
    val createdAt: Long,
    val updatedAt: Long,
    val userId: String = "local_user"
)

@Entity(
    tableName = "chat_messages",
    indices = [Index("sessionId")]
)
data class ChatMessageEntity(
    @PrimaryKey
    val id: String,
    val sessionId: String,
    val role: String, // "user" or "model"
    val content: String,
    val timestamp: Long,
    val status: String = "SUCCESS" // "SUCCESS", "ERROR", "GENERATING"
)

@Entity(tableName = "saved_documents")
data class SavedDocumentEntity(
    @PrimaryKey
    val id: String,
    val name: String,
    val uriString: String,
    val mimeType: String,
    val sizeBytes: Long,
    val extractedText: String,
    val summary: String = "",
    val createdAt: Long
)

@Entity(tableName = "user_usage_stats")
data class UserUsageEntity(
    @PrimaryKey
    val dateKey: String, // e.g. "2026-09-20"
    val chatQueriesUsed: Int = 0,
    val docsProcessed: Int = 0,
    val photosEdited: Int = 0,
    val isPremium: Boolean = false
)
