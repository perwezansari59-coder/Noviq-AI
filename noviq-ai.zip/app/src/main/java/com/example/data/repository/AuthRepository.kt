package com.example.data.repository

import android.content.Context
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseNetworkException
import com.google.firebase.FirebaseTooManyRequestsException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthException
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.auth.FirebaseAuthWeakPasswordException
import com.google.firebase.auth.FirebaseUser
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.tasks.await

data class AuthUserState(
    val isLoggedIn: Boolean = false,
    val uid: String = "",
    val email: String = "",
    val displayName: String = "",
    val isDemoUser: Boolean = false
)

sealed class AuthResult {
    data class Success(val user: AuthUserState) : AuthResult()
    data class Error(val message: String) : AuthResult()
}

class AuthRepository(private val context: Context) {
    private val prefs = context.getSharedPreferences("noviq_auth_prefs", Context.MODE_PRIVATE)

    private val firebaseAuth: FirebaseAuth?
        get() {
            return try {
                if (FirebaseApp.getApps(context).isEmpty()) {
                    FirebaseApp.initializeApp(context)
                }
                FirebaseAuth.getInstance()
            } catch (e: Exception) {
                null
            }
        }

    private val _currentUser = MutableStateFlow(loadInitialUser())
    val currentUser: StateFlow<AuthUserState> = _currentUser

    private fun loadInitialUser(): AuthUserState {
        val fbUser = firebaseAuth?.currentUser
        if (fbUser != null) {
            return AuthUserState(
                isLoggedIn = true,
                uid = fbUser.uid,
                email = fbUser.email ?: "",
                displayName = fbUser.displayName ?: fbUser.email?.substringBefore("@") ?: "User",
                isDemoUser = false
            )
        }

        // Check local saved session
        val savedEmail = prefs.getString("user_email", null)
        val savedUid = prefs.getString("user_uid", null)
        val isDemo = prefs.getBoolean("is_demo", false)

        return if (savedEmail != null && savedUid != null) {
            AuthUserState(
                isLoggedIn = true,
                uid = savedUid,
                email = savedEmail,
                displayName = savedEmail.substringBefore("@"),
                isDemoUser = isDemo
            )
        } else {
            AuthUserState(isLoggedIn = false)
        }
    }

    suspend fun login(email: String, pass: String): AuthResult {
        if (email.isBlank() || pass.isBlank()) {
            return AuthResult.Error("Please enter both email and password.")
        }
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            return AuthResult.Error("Please enter a valid email address.")
        }
        if (pass.length < 6) {
            return AuthResult.Error("Password must be at least 6 characters.")
        }

        val auth = firebaseAuth
        if (auth != null) {
            return try {
                val result = auth.signInWithEmailAndPassword(email.trim(), pass).await()
                val user = result.user
                if (user != null) {
                    val state = AuthUserState(
                        isLoggedIn = true,
                        uid = user.uid,
                        email = user.email ?: email.trim(),
                        displayName = user.displayName ?: email.substringBefore("@"),
                        isDemoUser = false
                    )
                    saveSession(state)
                    _currentUser.value = state
                    AuthResult.Success(state)
                } else {
                    AuthResult.Error("Authentication returned empty user profile.")
                }
            } catch (e: Throwable) {
                val parsedError = parseFirebaseAuthError(e)
                AuthResult.Error(parsedError)
            }
        }

        // Local fallback if Firebase not available
        return loginGuest()
    }

    suspend fun signup(email: String, pass: String): AuthResult {
        if (email.isBlank() || pass.isBlank()) {
            return AuthResult.Error("Please enter both email and password.")
        }
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            return AuthResult.Error("Please enter a valid email address.")
        }
        if (pass.length < 6) {
            return AuthResult.Error("Password must be at least 6 characters.")
        }

        val auth = firebaseAuth
        if (auth != null) {
            return try {
                val result = auth.createUserWithEmailAndPassword(email.trim(), pass).await()
                val user = result.user
                if (user != null) {
                    val state = AuthUserState(
                        isLoggedIn = true,
                        uid = user.uid,
                        email = user.email ?: email.trim(),
                        displayName = email.substringBefore("@"),
                        isDemoUser = false
                    )
                    saveSession(state)
                    _currentUser.value = state
                    AuthResult.Success(state)
                } else {
                    AuthResult.Error("Signup returned empty user profile.")
                }
            } catch (e: Throwable) {
                val parsedError = parseFirebaseAuthError(e)
                AuthResult.Error(parsedError)
            }
        }

        // Local fallback if Firebase not available
        return loginGuest()
    }

    fun loginGuest(): AuthResult {
        val demoState = AuthUserState(
            isLoggedIn = true,
            uid = "guest_noviq_user",
            email = "guest@noviq.ai",
            displayName = "Guest User",
            isDemoUser = true
        )
        saveSession(demoState)
        _currentUser.value = demoState
        return AuthResult.Success(demoState)
    }

    private fun parseFirebaseAuthError(e: Throwable): String {
        val rawMessage = e.message ?: e.localizedMessage ?: "Unknown authentication error"

        if (e is FirebaseNetworkException) {
            return "Network error: Unable to connect to Firebase. Please check your internet connection."
        }

        // Extract bracketed detail, e.g. "An internal error has occurred. [ CONFIGURATION_NOT_FOUND ]"
        val bracketMatch = Regex("""\[\s*([^\]]+?)\s*\]""").find(rawMessage)
        val bracketCode = bracketMatch?.groupValues?.getOrNull(1)?.trim() ?: ""

        val errorCode = if (e is FirebaseAuthException) e.errorCode else ""

        return when {
            bracketCode.contains("CONFIGURATION_NOT_FOUND", ignoreCase = true) -> {
                "Firebase Authentication is not activated in project 'noviq-ai-6d10f'. In the Firebase Console, go to Authentication > 'Get Started', and enable Email/Password under Sign-in method [CONFIGURATION_NOT_FOUND]."
            }
            bracketCode.contains("OPERATION_NOT_ALLOWED", ignoreCase = true) || errorCode == "ERROR_OPERATION_NOT_ALLOWED" -> {
                "Email/Password sign-in is not enabled in Firebase Console. In Firebase Console, go to Authentication > Sign-in method and enable Email/Password [OPERATION_NOT_ALLOWED]."
            }
            bracketCode.contains("API key not valid", ignoreCase = true) -> {
                "Firebase API key is invalid. Please check google-services.json configuration."
            }
            bracketCode.contains("Identity Toolkit API", ignoreCase = true) -> {
                "Identity Toolkit API is not enabled in Google Cloud Console for project 969118265255."
            }
            bracketCode.contains("EMAIL_EXISTS", ignoreCase = true) ||
            errorCode == "ERROR_EMAIL_ALREADY_IN_USE" ||
            e is FirebaseAuthUserCollisionException -> {
                "This email address is already registered. Please switch to Sign In."
            }
            bracketCode.contains("EMAIL_NOT_FOUND", ignoreCase = true) ||
            errorCode == "ERROR_USER_NOT_FOUND" ||
            e is FirebaseAuthInvalidUserException -> {
                "No account found with this email. Please switch to Sign Up to create an account."
            }
            bracketCode.contains("INVALID_LOGIN_CREDENTIALS", ignoreCase = true) ||
            bracketCode.contains("INVALID_PASSWORD", ignoreCase = true) ||
            errorCode == "ERROR_WRONG_PASSWORD" ||
            errorCode == "ERROR_INVALID_CREDENTIAL" ||
            e is FirebaseAuthInvalidCredentialsException -> {
                "Incorrect email or password. Please check your credentials and try again."
            }
            bracketCode.contains("USER_DISABLED", ignoreCase = true) || errorCode == "ERROR_USER_DISABLED" -> {
                "This account has been disabled by an administrator."
            }
            bracketCode.contains("TOO_MANY_ATTEMPTS_TRY_LATER", ignoreCase = true) ||
            errorCode == "ERROR_TOO_MANY_REQUESTS" ||
            e is FirebaseTooManyRequestsException -> {
                "Too many failed login attempts. Access is temporarily blocked. Please try again later."
            }
            bracketCode.contains("WEAK_PASSWORD", ignoreCase = true) ||
            errorCode == "ERROR_WEAK_PASSWORD" ||
            e is FirebaseAuthWeakPasswordException -> {
                val reason = (e as? FirebaseAuthWeakPasswordException)?.reason
                if (!reason.isNullOrBlank()) "Weak password: $reason"
                else "Password is too weak. Please use at least 6 characters with mixed characters."
            }
            bracketCode.contains("INVALID_EMAIL", ignoreCase = true) || errorCode == "ERROR_INVALID_EMAIL" -> {
                "The email address is invalid. Please enter a valid email format."
            }
            bracketCode.isNotBlank() -> {
                "Firebase Auth error: $bracketCode"
            }
            rawMessage.contains("internal error", ignoreCase = true) -> {
                "Firebase internal error. Verify that Firebase Authentication and Email/Password sign-in are enabled in project 'noviq-ai-6d10f' in the Firebase Console."
            }
            else -> rawMessage
        }
    }

    fun logout() {
        try {
            firebaseAuth?.signOut()
        } catch (ignored: Exception) {}

        prefs.edit().clear().apply()
        _currentUser.value = AuthUserState(isLoggedIn = false)
    }

    private fun saveSession(state: AuthUserState) {
        prefs.edit()
            .putString("user_email", state.email)
            .putString("user_uid", state.uid)
            .putBoolean("is_demo", state.isDemoUser)
            .apply()
        }
}
