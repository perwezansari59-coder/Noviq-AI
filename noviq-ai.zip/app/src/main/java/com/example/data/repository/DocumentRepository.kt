package com.example.data.repository

import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.provider.OpenableColumns
import com.example.BuildConfig
import com.example.data.api.GeminiApiClient
import com.example.data.api.GeminiContent
import com.example.data.api.GeminiGenerationConfig
import com.example.data.api.GeminiPart
import com.example.data.api.GenerateContentRequest
import com.example.data.local.DocumentDao
import com.example.data.local.SavedDocumentEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.UUID

sealed class DocumentProcessResult {
    data class Success(val doc: SavedDocumentEntity) : DocumentProcessResult()
    data class Error(val message: String) : DocumentProcessResult()
}

class DocumentRepository(
    private val context: Context,
    private val documentDao: DocumentDao,
    private val usageManager: UsageManager
) {
    val allDocuments: Flow<List<SavedDocumentEntity>> = documentDao.getAllDocuments()

    suspend fun importDocument(uri: Uri): DocumentProcessResult = withContext(Dispatchers.IO) {
        try {
            var fileName = "document"
            var fileSize = 0L

            context.contentResolver.query(uri, null, null, null, null)?.use { cursor: Cursor ->
                if (cursor.moveToFirst()) {
                    val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (nameIndex != -1) fileName = cursor.getString(nameIndex) ?: "document"
                    if (sizeIndex != -1) fileSize = cursor.getLong(sizeIndex)
                }
            }

            val mimeType = context.contentResolver.getType(uri) ?: "application/octet-stream"

            // Extract text from supported formats
            val extractedText = try {
                context.contentResolver.openInputStream(uri)?.use { stream ->
                    val reader = BufferedReader(InputStreamReader(stream))
                    val sb = StringBuilder()
                    var line = reader.readLine()
                    var lineCount = 0
                    // Read up to 20,000 chars for safety
                    while (line != null && sb.length < 20000) {
                        sb.append(line).append("\n")
                        line = reader.readLine()
                        lineCount++
                    }
                    sb.toString()
                } ?: ""
            } catch (e: Exception) {
                return@withContext DocumentProcessResult.Error("Could not read file content: ${e.localizedMessage}")
            }

            if (extractedText.isBlank()) {
                return@withContext DocumentProcessResult.Error(
                    "No readable plain-text could be extracted from '$fileName'. Please select a TXT, CSV, JSON, MD, or text-encoded file."
                )
            }

            val entity = SavedDocumentEntity(
                id = UUID.randomUUID().toString(),
                name = fileName,
                uriString = uri.toString(),
                mimeType = mimeType,
                sizeBytes = fileSize,
                extractedText = extractedText.trim(),
                summary = "",
                createdAt = System.currentTimeMillis()
            )

            documentDao.insertDocument(entity)
            DocumentProcessResult.Success(entity)
        } catch (e: Exception) {
            DocumentProcessResult.Error("Failed to process document: ${e.localizedMessage}")
        }
    }

    suspend fun summarizeDocument(doc: SavedDocumentEntity): Result<String> = withContext(Dispatchers.IO) {
        if (!usageManager.recordDocQuery()) {
            return@withContext Result.failure(
                Exception("Daily free document limit reached (${UsageManager.FREE_DOC_LIMIT}/${UsageManager.FREE_DOC_LIMIT}). Upgrade to Noviq AI Premium for unlimited document analysis.")
            )
        }

        val apiKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Throwable) {
            ""
        }

        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext Result.failure(
                Exception("Gemini API key is not configured. Please add GEMINI_API_KEY in AI Studio Secrets panel.")
            )
        }

        try {
            val prompt = "Please provide an executive, structured summary of the following document content:\n\n" +
                    doc.extractedText.take(12000)

            val request = GenerateContentRequest(
                contents = listOf(
                    GeminiContent(
                        role = "user",
                        parts = listOf(GeminiPart(text = prompt))
                    )
                ),
                systemInstruction = GeminiContent(
                    parts = listOf(
                        GeminiPart(text = "You are Noviq AI Document Intelligence. Provide accurate, factual summaries with key takeaways and bullet points. Never hallucinate facts.")
                    )
                ),
                generationConfig = GeminiGenerationConfig(temperature = 0.3f, maxOutputTokens = 1500)
            )

            val resp = GeminiApiClient.apiService.generateContent(apiKey, request)
            val summary = resp.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                ?: resp.error?.message
                ?: "Could not generate summary."

            // Update in database
            documentDao.insertDocument(doc.copy(summary = summary))
            Result.success(summary)
        } catch (e: Exception) {
            Result.failure(Exception("Document summarization failed: ${e.localizedMessage}"))
        }
    }

    suspend fun askDocumentQuestion(doc: SavedDocumentEntity, question: String): Result<String> = withContext(Dispatchers.IO) {
        if (question.isBlank()) return@withContext Result.failure(Exception("Question cannot be empty."))

        if (!usageManager.recordDocQuery()) {
            return@withContext Result.failure(
                Exception("Daily free document limit reached. Upgrade to Noviq AI Premium for unlimited document analysis.")
            )
        }

        val apiKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Throwable) {
            ""
        }

        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext Result.failure(
                Exception("Gemini API key is not configured. Please add GEMINI_API_KEY in AI Studio Secrets panel.")
            )
        }

        try {
            val prompt = "Context Document Content:\n\"\"\"\n${doc.extractedText.take(12000)}\n\"\"\"\n\n" +
                    "User Question: $question\n\n" +
                    "Answer strictly and accurately based on the context above. If the context does not contain the answer, clearly state so."

            val request = GenerateContentRequest(
                contents = listOf(
                    GeminiContent(
                        role = "user",
                        parts = listOf(GeminiPart(text = prompt))
                    )
                ),
                systemInstruction = GeminiContent(
                    parts = listOf(
                        GeminiPart(text = "You are Noviq AI Document Analyst. Answer questions strictly according to the provided text context.")
                    )
                ),
                generationConfig = GeminiGenerationConfig(temperature = 0.2f, maxOutputTokens = 1000)
            )

            val resp = GeminiApiClient.apiService.generateContent(apiKey, request)
            val answer = resp.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                ?: resp.error?.message
                ?: "No response generated."

            Result.success(answer)
        } catch (e: Exception) {
            Result.failure(Exception("Failed to answer question: ${e.localizedMessage}"))
        }
    }

    suspend fun deleteDocument(id: String) = withContext(Dispatchers.IO) {
        documentDao.deleteDocument(id)
    }
}
