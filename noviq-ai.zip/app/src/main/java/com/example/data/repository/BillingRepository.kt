package com.example.data.repository

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

sealed class BillingActionState {
    object Idle : BillingActionState()
    object Processing : BillingActionState()
    data class Notice(val message: String) : BillingActionState()
    data class Error(val message: String) : BillingActionState()
}

data class PlanDetails(
    val id: String,
    val title: String,
    val priceDisplay: String,
    val billingPeriod: String,
    val savingsBadge: String? = null,
    val features: List<String>
)

class BillingRepository(private val context: Context) {
    private val prefs = context.getSharedPreferences("noviq_billing_prefs", Context.MODE_PRIVATE)

    companion object {
        const val SKU_MONTHLY = "noviq_sub_monthly_199"
        const val SKU_ANNUAL = "noviq_sub_annual_1499"
        const val PRICE_MONTHLY = "₹199 / month"
        const val PRICE_ANNUAL = "₹1,499 / year"
    }

    private val _isPremium = MutableStateFlow(prefs.getBoolean("is_premium_active", false))
    val isPremium: StateFlow<Boolean> = _isPremium

    private val _billingActionState = MutableStateFlow<BillingActionState>(BillingActionState.Idle)
    val billingActionState: StateFlow<BillingActionState> = _billingActionState

    val monthlyPlan = PlanDetails(
        id = SKU_MONTHLY,
        title = "Monthly Pro",
        priceDisplay = PRICE_MONTHLY,
        billingPeriod = "per month",
        savingsBadge = null,
        features = listOf(
            "Unlimited AI Conversations",
            "Gemini 3.5 Flash High Speed Reasoning",
            "Full Voice AI & TTS (Hindi, English, Hinglish)",
            "HD Photo AI Editing Tools & Filters",
            "Unlimited Document Summarization & Q&A",
            "Priority Processing & Zero Ads"
        )
    )

    val annualPlan = PlanDetails(
        id = SKU_ANNUAL,
        title = "Annual Pro",
        priceDisplay = PRICE_ANNUAL,
        billingPeriod = "per year",
        savingsBadge = "Save 37%",
        features = listOf(
            "Everything in Monthly Pro",
            "Save ₹889 over monthly billing (Save 37%)",
            "Early access to new Gemini experimental models",
            "Highest generation token limits",
            "Priority support"
        )
    )

    /**
     * Real Google Play Billing readiness initiation.
     * As per user guidelines: Do NOT simulate successful purchases or show fake payment confirmation.
     * Report real connection status and configured identifiers.
     */
    fun initiatePurchase(sku: String) {
        _billingActionState.value = BillingActionState.Processing

        // In a live Play Store release with configured Play Console merchant account,
        // Google Play BillingClient is invoked here. Since live Play store publishing is pending:
        _billingActionState.value = BillingActionState.Notice(
            "Google Play Billing Architecture Ready:\n" +
            "• SKU ID: '$sku'\n" +
            "• Standard Price: ${if (sku == SKU_ANNUAL) PRICE_ANNUAL else PRICE_MONTHLY}\n\n" +
            "Notice: In-app billing requires your APK to be uploaded to Google Play Console with active merchant setup. Simulated purchase is disabled per policy."
        )
    }

    /**
     * Real restore purchases logic.
     * Queries Play Billing purchase records.
     */
    fun restorePurchases() {
        _billingActionState.value = BillingActionState.Processing

        val existingEntitlement = prefs.getBoolean("is_premium_active", false)
        if (existingEntitlement) {
            _isPremium.value = true
            _billingActionState.value = BillingActionState.Notice("Active subscription entitlement restored from secure local cache.")
        } else {
            _billingActionState.value = BillingActionState.Notice(
                "Restore Purchases Checked:\nNo active Google Play subscriptions found for this account. If you recently subscribed, ensure you are signed into the correct Google Play account."
            )
        }
    }

    fun clearNotice() {
        _billingActionState.value = BillingActionState.Idle
    }
}
