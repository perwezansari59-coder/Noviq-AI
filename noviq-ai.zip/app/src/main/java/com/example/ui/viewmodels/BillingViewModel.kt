package com.example.ui.viewmodels

import androidx.lifecycle.ViewModel
import com.example.data.repository.BillingActionState
import com.example.data.repository.BillingRepository
import kotlinx.coroutines.flow.StateFlow

class BillingViewModel(private val repository: BillingRepository) : ViewModel() {
    val isPremium: StateFlow<Boolean> = repository.isPremium
    val billingActionState: StateFlow<BillingActionState> = repository.billingActionState

    val monthlyPlan = repository.monthlyPlan
    val annualPlan = repository.annualPlan

    fun initiatePurchase(sku: String) {
        repository.initiatePurchase(sku)
    }

    fun restorePurchases() {
        repository.restorePurchases()
    }

    fun clearNotice() {
        repository.clearNotice()
    }
}
