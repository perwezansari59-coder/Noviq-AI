package com.example.ui.viewmodels

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.SavedDocumentEntity
import com.example.data.repository.DocumentProcessResult
import com.example.data.repository.DocumentRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class FilesViewModel(private val repository: DocumentRepository) : ViewModel() {

    val allDocuments: StateFlow<List<SavedDocumentEntity>> = repository.allDocuments
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _selectedDocument = MutableStateFlow<SavedDocumentEntity?>(null)
    val selectedDocument: StateFlow<SavedDocumentEntity?> = _selectedDocument

    private val _isProcessing = MutableStateFlow(false)
    val isProcessing: StateFlow<Boolean> = _isProcessing

    private val _qaResult = MutableStateFlow<String?>(null)
    val qaResult: StateFlow<String?> = _qaResult

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage

    val questionText = MutableStateFlow("")

    fun onDocumentSelected(uri: Uri?) {
        if (uri == null) return
        viewModelScope.launch {
            _isProcessing.value = true
            when (val res = repository.importDocument(uri)) {
                is DocumentProcessResult.Success -> {
                    _selectedDocument.value = res.doc
                    _statusMessage.value = "Document loaded successfully: ${res.doc.name}"
                }
                is DocumentProcessResult.Error -> {
                    _statusMessage.value = res.message
                }
            }
            _isProcessing.value = false
        }
    }

    fun selectDocument(doc: SavedDocumentEntity) {
        _selectedDocument.value = doc
        _qaResult.value = null
    }

    fun summarizeSelected() {
        val doc = _selectedDocument.value ?: return
        viewModelScope.launch {
            _isProcessing.value = true
            val result = repository.summarizeDocument(doc)
            result.onSuccess { summary ->
                _selectedDocument.value = doc.copy(summary = summary)
                _statusMessage.value = "Document summary generated successfully."
            }.onFailure { err ->
                _statusMessage.value = err.localizedMessage ?: "Failed to generate summary."
            }
            _isProcessing.value = false
        }
    }

    fun askQuestion() {
        val q = questionText.value.trim()
        val doc = _selectedDocument.value ?: return
        if (q.isBlank()) return

        viewModelScope.launch {
            _isProcessing.value = true
            val result = repository.askDocumentQuestion(doc, q)
            result.onSuccess { answer ->
                _qaResult.value = answer
            }.onFailure { err ->
                _statusMessage.value = err.localizedMessage ?: "Failed to answer question."
            }
            _isProcessing.value = false
        }
    }

    fun deleteDocument(id: String) {
        viewModelScope.launch {
            repository.deleteDocument(id)
            if (_selectedDocument.value?.id == id) {
                _selectedDocument.value = null
                _qaResult.value = null
            }
            _statusMessage.value = "Document reference removed."
        }
    }

    fun clearStatus() {
        _statusMessage.value = null
    }

    fun clearSelected() {
        _selectedDocument.value = null
        _qaResult.value = null
        questionText.value = ""
    }
}
