package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.UserUsage
import com.example.ui.theme.NoviqBackground
import com.example.ui.theme.NoviqBlue
import com.example.ui.theme.NoviqCyan
import com.example.ui.theme.NoviqGold
import com.example.ui.theme.NoviqSurface
import com.example.ui.theme.NoviqSurfaceBorder
import com.example.ui.theme.NoviqSurfaceVariant
import com.example.ui.theme.NoviqTextPrimary
import com.example.ui.theme.NoviqTextSecondary
import com.example.ui.theme.NoviqViolet

@Composable
fun HomeScreen(
    usage: UserUsage? = null,
    isPremium: Boolean = false,
    onNavigateToChat: (prompt: String?) -> Unit,
    onNavigateToPhotoEditor: () -> Unit,
    onNavigateToFiles: () -> Unit,
    onNavigateToVoice: () -> Unit,
    onNavigateToSettings: () -> Unit,
    onUpgradeClick: () -> Unit = {}
) {
    Surface(
        modifier = Modifier
            .fillMaxSize()
            .testTag("home_screen"),
        color = NoviqBackground
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 24.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // Header: Branding & Settings Shortcut
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    Brush.linearGradient(listOf(NoviqCyan, NoviqViolet))
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = "Logo",
                                tint = Color.White,
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        Column {
                            Text(
                                text = "NOVIQ AI",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.ExtraBold,
                                letterSpacing = 1.sp,
                                color = NoviqTextPrimary
                            )
                            Text(
                                text = "Smart Multilingual Assistant",
                                fontSize = 12.sp,
                                color = NoviqCyan
                            )
                        }
                    }

                    IconButton(
                        onClick = onNavigateToSettings,
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(NoviqSurface)
                            .testTag("home_settings_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Settings",
                            tint = NoviqTextSecondary
                        )
                    }
                }
            }

            // Quick Voice AI Access Banner
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onNavigateToVoice() }
                        .testTag("voice_ai_banner"),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = NoviqSurfaceVariant
                    ),
                    border = androidx.compose.foundation.BorderStroke(1.dp, NoviqCyan.copy(alpha = 0.4f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .background(NoviqCyan),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Mic,
                                    contentDescription = "Voice AI",
                                    tint = Color.Black,
                                    modifier = Modifier.size(28.dp)
                                )
                            }

                            Column {
                                Text(
                                    text = "Speak with Noviq AI",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp,
                                    color = NoviqTextPrimary
                                )
                                Text(
                                    text = "Supports Hindi, English & Hinglish",
                                    fontSize = 12.sp,
                                    color = NoviqCyan
                                )
                            }
                        }

                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = null,
                            tint = NoviqTextSecondary
                        )
                    }
                }
            }

            // Features Grid
            item {
                Text(
                    text = "AI Capabilities",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = NoviqTextPrimary
                )
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    FeatureCard(
                        title = "AI Chat",
                        desc = "Multilingual Smart Chat",
                        icon = Icons.Default.ChatBubble,
                        accentColor = NoviqCyan,
                        modifier = Modifier.weight(1f),
                        testTag = "home_chat_card",
                        onClick = { onNavigateToChat(null) }
                    )

                    FeatureCard(
                        title = "Photo AI",
                        desc = "Crop, Adjust & Enhance",
                        icon = Icons.Default.Image,
                        accentColor = NoviqViolet,
                        modifier = Modifier.weight(1f),
                        testTag = "home_photo_card",
                        onClick = onNavigateToPhotoEditor
                    )
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    FeatureCard(
                        title = "Document AI",
                        desc = "Summarize & Q&A",
                        icon = Icons.Default.Description,
                        accentColor = NoviqBlue,
                        modifier = Modifier.weight(1f),
                        testTag = "home_files_card",
                        onClick = onNavigateToFiles
                    )

                    FeatureCard(
                        title = "Settings",
                        desc = "Voice, TTS & Account",
                        icon = Icons.Default.Settings,
                        accentColor = NoviqTextSecondary,
                        modifier = Modifier.weight(1f),
                        testTag = "home_settings_card",
                        onClick = onNavigateToSettings
                    )
                }
            }

            // Suggested Prompts
            item {
                Text(
                    text = "Suggested Prompts",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = NoviqTextPrimary
                )
            }

            val suggestions = listOf(
                "Explain quantum computing in simple Hinglish",
                "भारत के प्रमुख वैज्ञानिकों के बारे में बताइए",
                "Write a professional email requesting project review",
                "5 daily habits for high productivity"
            )

            items(suggestions) { prompt ->
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onNavigateToChat(prompt) },
                    shape = RoundedCornerShape(12.dp),
                    color = NoviqSurface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, NoviqSurfaceBorder)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = prompt,
                            fontSize = 13.sp,
                            color = NoviqTextSecondary,
                            modifier = Modifier.weight(1f)
                        )
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = NoviqCyan,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun FeatureCard(
    title: String,
    desc: String,
    icon: ImageVector,
    accentColor: Color,
    modifier: Modifier = Modifier,
    testTag: String,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .clickable { onClick() }
            .testTag(testTag),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = NoviqSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, NoviqSurfaceBorder)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(accentColor.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = accentColor,
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = title,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = NoviqTextPrimary
            )

            Text(
                text = desc,
                fontSize = 12.sp,
                color = NoviqTextSecondary,
                modifier = Modifier.padding(top = 2.dp)
            )
        }
    }
}
