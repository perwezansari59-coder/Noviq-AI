package com.example.ui.viewmodels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.BuildConfig
import com.example.data.repository.AuthRepository
import com.example.data.repository.AuthUserState
import com.example.data.repository.BillingRepository
import com.example.data.repository.GeminiChatRepository
import com.example.data.repository.UsageManager
import com.example.data.repository.UserUsage
import com.example.service.TextToSpeechHelper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class SettingsViewModel(
    private val authRepository: AuthRepository,
    private val billingRepository: BillingRepository,
    private val usageManager: UsageManager,
    private val chatRepository: GeminiChatRepository,
    private val ttsHelper: TextToSpeechHelper
) : ViewModel() {

    val currentUser: StateFlow<AuthUserState> = authRepository.currentUser
    val userUsage: StateFlow<UserUsage> = usageManager.usage
    val isPremium: StateFlow<Boolean> = billingRepository.isPremium

    val speechPitch = MutableStateFlow(1.0f)
    val speechRate = MutableStateFlow(1.0f)
    val speechLang = MutableStateFlow("en") // "en", "hi", "auto"

    private val _statusNotice = MutableStateFlow<String?>(null)
    val statusNotice: StateFlow<String?> = _statusNotice

    fun isApiKeyConfigured(): Boolean {
        return try {
            BuildConfig.GEMINI_API_KEY.isNotBlank() && BuildConfig.GEMINI_API_KEY != "MY_GEMINI_API_KEY"
        } catch (e: Throwable) {
            false
        }
    }

    fun updateTtsSettings(pitch: Float, rate: Float, lang: String) {
        speechPitch.value = pitch
        speechRate.value = rate
        speechLang.value = lang
        ttsHelper.setSpeechParameters(pitch, rate, lang)
    }

    fun testVoice() {
        val text = when (speechLang.value) {
            "hi" -> "नमस्ते! मैं नोविक एआई हूँ। आपकी कैसे मदद करूँ?"
            "auto" -> "Hello! Main Noviq AI hoon. How can I help you today?"
            else -> "Hello! I am Noviq AI, your personal intelligence assistant."
        }
        ttsHelper.setSpeechParameters(speechPitch.value, speechRate.value, speechLang.value)
        ttsHelper.speak("test_voice", text)
    }

    fun clearAllChatHistory() {
        viewModelScope.launch {
            chatRepository.clearAllChats()
            _statusNotice.value = "All chat history cleared."
        }
    }

    fun restorePurchases() {
        billingRepository.restorePurchases()
    }

    fun logout() {
        authRepository.logout()
    }

    fun clearNotice() {
        _statusNotice.value = null
    }
}
