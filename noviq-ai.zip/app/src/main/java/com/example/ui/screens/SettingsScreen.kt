package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.NoviqBackground
import com.example.ui.theme.NoviqCyan
import com.example.ui.theme.NoviqError
import com.example.ui.theme.NoviqGold
import com.example.ui.theme.NoviqSurface
import com.example.ui.theme.NoviqSurfaceBorder
import com.example.ui.theme.NoviqSurfaceVariant
import com.example.ui.theme.NoviqTextPrimary
import com.example.ui.theme.NoviqTextSecondary
import com.example.ui.viewmodels.SettingsViewModel

@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel,
    onUpgradeClick: () -> Unit,
    onLoggedOut: () -> Unit
) {
    val currentUser by viewModel.currentUser.collectAsState()
    val usage by viewModel.userUsage.collectAsState()
    val isPremium by viewModel.isPremium.collectAsState()
    val statusNotice by viewModel.statusNotice.collectAsState()

    val speechPitch by viewModel.speechPitch.collectAsState()
    val speechRate by viewModel.speechRate.collectAsState()
    val speechLang by viewModel.speechLang.collectAsState()

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .testTag("settings_screen"),
        containerColor = NoviqBackground,
        topBar = {
            Surface(
                color = NoviqSurface,
                border = androidx.compose.foundation.BorderStroke(1.dp, NoviqSurfaceBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Settings & Preferences",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = NoviqTextPrimary
                    )
                }
            }
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Status notice
            if (statusNotice != null) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = NoviqSurfaceVariant),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = statusNotice ?: "",
                                fontSize = 13.sp,
                                color = NoviqCyan,
                                modifier = Modifier.weight(1f)
                            )
                            Button(
                                onClick = { viewModel.clearNotice() },
                                colors = ButtonDefaults.buttonColors(containerColor = NoviqCyan, contentColor = Color.Black),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                modifier = Modifier.height(30.dp)
                            ) {
                                Text("OK", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }

            // Account Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = NoviqSurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, NoviqSurfaceBorder)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .background(NoviqCyan.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AccountCircle,
                                    contentDescription = null,
                                    tint = NoviqCyan,
                                    modifier = Modifier.size(28.dp)
                                )
                            }

                            Column {
                                Text(
                                    text = if (currentUser.isLoggedIn) currentUser.email else "Not logged in",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = NoviqTextPrimary
                                )
                                Text(
                                    text = if (currentUser.isDemoUser) "Guest / Demo Session" else "Authenticated Cloud User",
                                    fontSize = 12.sp,
                                    color = NoviqTextSecondary
                                )
                            }
                        }
                    }
                }
            }

            // Subscription & Billing Section
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = NoviqSurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, if (isPremium) NoviqGold else NoviqSurfaceBorder)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.WorkspacePremium,
                                    contentDescription = null,
                                    tint = if (isPremium) NoviqGold else NoviqCyan
                                )
                                Text(
                                    text = if (isPremium) "Plan: Premium Pro" else "Plan: Free Tier",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = if (isPremium) NoviqGold else NoviqTextPrimary
                                )
                            }

                            if (!isPremium) {
                                Button(
                                    onClick = onUpgradeClick,
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = NoviqCyan,
                                        contentColor = Color.Black
                                    ),
                                    shape = RoundedCornerShape(16.dp),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                    modifier = Modifier.height(32.dp)
                                ) {
                                    Text("Upgrade Pro", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Usage info
                        Text(
                            text = "Daily Quota Usage:",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = NoviqTextSecondary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "• Chat queries: ${usage.chatUsed}/${if (isPremium) "∞" else usage.chatMax}\n" +
                                    "• Document analysis: ${usage.docUsed}/${if (isPremium) "∞" else usage.docMax}\n" +
                                    "• Photo AI adjustments: ${usage.photoUsed}/${if (isPremium) "∞" else usage.photoMax}",
                            fontSize = 12.sp,
                            color = NoviqTextSecondary,
                            lineHeight = 18.sp
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedButton(
                            onClick = { viewModel.restorePurchases() },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.Restore, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Restore Play Store Purchases", fontSize = 12.sp, color = NoviqCyan)
                        }
                    }
                }
            }

            // Voice & Text-to-Speech Settings
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = NoviqSurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, NoviqSurfaceBorder)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.RecordVoiceOver, contentDescription = null, tint = NoviqCyan)
                            Text(
                                text = "Voice & Text-to-Speech (TTS)",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = NoviqTextPrimary
                            )
                        }

                        // Language selector
                        Text("Speech Output Language:", fontSize = 12.sp, color = NoviqTextSecondary)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(
                                selected = speechLang == "en",
                                onClick = { viewModel.updateTtsSettings(speechPitch, speechRate, "en") },
                                label = { Text("English") },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = NoviqCyan,
                                    selectedLabelColor = Color.Black
                                )
                            )
                            FilterChip(
                                selected = speechLang == "hi",
                                onClick = { viewModel.updateTtsSettings(speechPitch, speechRate, "hi") },
                                label = { Text("हिन्दी") },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = NoviqCyan,
                                    selectedLabelColor = Color.Black
                                )
                            )
                            FilterChip(
                                selected = speechLang == "auto",
                                onClick = { viewModel.updateTtsSettings(speechPitch, speechRate, "auto") },
                                label = { Text("Hinglish / Auto") },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = NoviqCyan,
                                    selectedLabelColor = Color.Black
                                )
                            )
                        }

                        // Pitch Slider
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Speech Pitch", fontSize = 12.sp, color = NoviqTextSecondary)
                                Text("${(speechPitch * 100).toInt()}%", fontSize = 12.sp, color = NoviqCyan)
                            }
                            Slider(
                                value = speechPitch,
                                onValueChange = { viewModel.updateTtsSettings(it, speechRate, speechLang) },
                                valueRange = 0.5f..2.0f,
                                colors = SliderDefaults.colors(thumbColor = NoviqCyan, activeTrackColor = NoviqCyan)
                            )
                        }

                        // Speed Slider
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Speech Speed Rate", fontSize = 12.sp, color = NoviqTextSecondary)
                                Text("${(speechRate * 100).toInt()}%", fontSize = 12.sp, color = NoviqCyan)
                            }
                            Slider(
                                value = speechRate,
                                onValueChange = { viewModel.updateTtsSettings(speechPitch, it, speechLang) },
                                valueRange = 0.5f..2.0f,
                                colors = SliderDefaults.colors(thumbColor = NoviqCyan, activeTrackColor = NoviqCyan)
                            )
                        }

                        Button(
                            onClick = { viewModel.testVoice() },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = NoviqSurfaceVariant,
                                contentColor = NoviqCyan
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Test Voice Speech Sample")
                        }
                    }
                }
            }

            // App & API Status
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = NoviqSurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, NoviqSurfaceBorder)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.Info, contentDescription = null, tint = NoviqCyan)
                            Text(
                                text = "System & Model Status",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = NoviqTextPrimary
                            )
                        }

                        val keyConfigured = viewModel.isApiKeyConfigured()
                        Text(
                            text = "• AI Engine: Gemini 3.5 Flash (Multilingual)\n" +
                                    "• Gemini API Key: ${if (keyConfigured) "Configured in Environment ✓" else "Requires GEMINI_API_KEY in Secrets"}\n" +
                                    "• Version: Noviq AI v1.0.0 Production Build",
                            fontSize = 12.sp,
                            color = NoviqTextSecondary,
                            lineHeight = 18.sp
                        )
                    }
                }
            }

            // Actions: Clear Chat History & Logout
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(
                        onClick = { viewModel.clearAllChatHistory() },
                        modifier = Modifier.fillMaxWidth(),
                        border = androidx.compose.foundation.BorderStroke(1.dp, NoviqSurfaceBorder)
                    ) {
                        Icon(Icons.Default.DeleteSweep, contentDescription = null, tint = NoviqTextSecondary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Clear All Chat History", color = NoviqTextSecondary)
                    }

                    Button(
                        onClick = {
                            viewModel.logout()
                            onLoggedOut()
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = NoviqError.copy(alpha = 0.15f),
                            contentColor = NoviqError
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null, tint = NoviqError)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Sign Out", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
