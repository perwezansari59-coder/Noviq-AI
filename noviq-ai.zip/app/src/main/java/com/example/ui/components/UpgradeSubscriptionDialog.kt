package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.BillingActionState
import com.example.data.repository.BillingRepository
import com.example.ui.theme.NoviqCyan
import com.example.ui.theme.NoviqGold
import com.example.ui.theme.NoviqSurface
import com.example.ui.theme.NoviqSurfaceBorder
import com.example.ui.theme.NoviqSurfaceVariant
import com.example.ui.theme.NoviqTextPrimary
import com.example.ui.theme.NoviqTextSecondary
import com.example.ui.theme.NoviqViolet
import com.example.ui.viewmodels.BillingViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UpgradeSubscriptionDialog(
    viewModel: BillingViewModel,
    onDismiss: () -> Unit
) {
    val isPremium by viewModel.isPremium.collectAsState()
    val billingActionState by viewModel.billingActionState.collectAsState()

    var selectedSku by remember { mutableStateOf(BillingRepository.SKU_ANNUAL) }

    // Billing Notice Dialog (Real Play Store Integration Status)
    if (billingActionState is BillingActionState.Notice) {
        val notice = (billingActionState as BillingActionState.Notice).message
        AlertDialog(
            onDismissRequest = { viewModel.clearNotice() },
            containerColor = NoviqSurface,
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.WorkspacePremium, contentDescription = null, tint = NoviqGold)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Google Play Billing", color = NoviqTextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Text(
                    text = notice,
                    color = NoviqTextSecondary,
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = { viewModel.clearNotice() },
                    colors = ButtonDefaults.buttonColors(containerColor = NoviqCyan, contentColor = Color.Black)
                ) {
                    Text("Understood")
                }
            }
        )
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = NoviqSurface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Brush.linearGradient(listOf(NoviqGold, NoviqViolet))),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.WorkspacePremium,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }

                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = NoviqTextSecondary)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "Upgrade to Noviq AI Pro",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = NoviqTextPrimary
            )

            Text(
                text = "Unlock unlimited queries, voice TTS & HD multimodal tools",
                fontSize = 12.sp,
                color = NoviqCyan,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 4.dp)
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Plan 1: Annual Pro (₹1,499 / year - Save 37%)
            PlanSelectionCard(
                title = "Annual Pro",
                price = "₹1,499 / year",
                badge = "SAVE 37%",
                subtitle = "₹124.90 / month • Billed annually",
                isSelected = selectedSku == BillingRepository.SKU_ANNUAL,
                onClick = { selectedSku = BillingRepository.SKU_ANNUAL }
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Plan 2: Monthly Pro (₹199 / month)
            PlanSelectionCard(
                title = "Monthly Pro",
                price = "₹199 / month",
                badge = null,
                subtitle = "Flexible month-to-month access",
                isSelected = selectedSku == BillingRepository.SKU_MONTHLY,
                onClick = { selectedSku = BillingRepository.SKU_MONTHLY }
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Features Checklist
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(NoviqSurfaceVariant, RoundedCornerShape(12.dp))
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FeatureRow("Unlimited Gemini 3.5 Flash Chat (Hindi & English)")
                FeatureRow("Full Voice Input & Text-to-Speech playback")
                FeatureRow("Document Intelligence & unlimited summaries")
                FeatureRow("HD Photo AI Editor & Enhancement suite")
                FeatureRow("Priority server response time & zero ads")
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Subscribe Button
            Button(
                onClick = {
                    viewModel.initiatePurchase(selectedSku)
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = NoviqCyan,
                    contentColor = Color.Black
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("subscribe_button")
            ) {
                Text(
                    text = if (selectedSku == BillingRepository.SKU_ANNUAL) "Start Annual Pro (₹1,499/yr)" else "Start Monthly Pro (₹199/mo)",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedButton(
                onClick = { viewModel.restorePurchases() },
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, NoviqSurfaceBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Restore Existing Purchase", color = NoviqTextSecondary, fontSize = 13.sp)
            }

            Spacer(modifier = Modifier.height(12.dp))
        }
    }
}

@Composable
fun PlanSelectionCard(
    title: String,
    price: String,
    badge: String?,
    subtitle: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) NoviqCyan.copy(alpha = 0.12f) else NoviqSurfaceVariant
        ),
        border = BorderStroke(
            if (isSelected) 1.5.dp else 1.dp,
            if (isSelected) NoviqCyan else NoviqSurfaceBorder
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = title,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = NoviqTextPrimary
                    )
                    if (badge != null) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = NoviqGold
                        ) {
                            Text(
                                text = badge,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color.Black,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
                Text(
                    text = subtitle,
                    fontSize = 11.sp,
                    color = NoviqTextSecondary,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }

            Text(
                text = price,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = if (isSelected) NoviqCyan else NoviqTextPrimary
            )
        }
    }
}

@Composable
fun FeatureRow(text: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Icon(
            imageVector = Icons.Default.Check,
            contentDescription = null,
            tint = NoviqCyan,
            modifier = Modifier.size(16.dp)
        )
        Text(text, fontSize = 12.sp, color = NoviqTextPrimary)
    }
}
