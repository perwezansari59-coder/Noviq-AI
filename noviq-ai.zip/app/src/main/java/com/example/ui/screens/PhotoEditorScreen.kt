package com.example.ui.screens

import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.RotateRight
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Crop
import androidx.compose.material.icons.filled.FilterHdr
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.NoviqBackground
import com.example.ui.theme.NoviqCyan
import com.example.ui.theme.NoviqError
import com.example.ui.theme.NoviqSurface
import com.example.ui.theme.NoviqSurfaceBorder
import com.example.ui.theme.NoviqSurfaceVariant
import com.example.ui.theme.NoviqTextPrimary
import com.example.ui.theme.NoviqTextSecondary
import com.example.ui.theme.NoviqViolet
import com.example.ui.viewmodels.PhotoEditorViewModel

@Composable
fun PhotoEditorScreen(viewModel: PhotoEditorViewModel) {
    val context = LocalContext.current
    val originalBitmap by viewModel.originalBitmap.collectAsState()
    val editedBitmap by viewModel.editedBitmap.collectAsState()
    val params by viewModel.params.collectAsState()
    val isProcessing by viewModel.isProcessing.collectAsState()
    val statusMessage by viewModel.statusMessage.collectAsState()
    val aiInstruction by viewModel.aiInstruction.collectAsState()
    val isComparingBefore by viewModel.isComparingBefore.collectAsState()

    var activeTab by remember { mutableStateOf("adjust") } // "adjust", "ai", "crop"

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        viewModel.onImageSelected(uri)
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .testTag("photo_editor_screen"),
        containerColor = NoviqBackground,
        topBar = {
            Surface(
                color = NoviqSurface,
                border = androidx.compose.foundation.BorderStroke(1.dp, NoviqSurfaceBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Photo AI Editor",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = NoviqTextPrimary
                        )
                        Text(
                            text = "Real Adjustment & Intelligent Enhancements",
                            fontSize = 11.sp,
                            color = NoviqCyan
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        if (editedBitmap != null) {
                            IconButton(
                                onClick = { viewModel.shareImage(context) },
                                modifier = Modifier.testTag("photo_share_button")
                            ) {
                                Icon(Icons.Default.Share, contentDescription = "Share", tint = NoviqCyan)
                            }

                            IconButton(
                                onClick = { viewModel.saveImage() },
                                modifier = Modifier.testTag("photo_save_button")
                            ) {
                                Icon(Icons.Default.Save, contentDescription = "Save", tint = NoviqCyan)
                            }
                        }

                        IconButton(
                            onClick = {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            modifier = Modifier.testTag("photo_pick_button")
                        ) {
                            Icon(
                                Icons.Default.AddPhotoAlternate,
                                contentDescription = "Select Photo",
                                tint = NoviqTextPrimary
                            )
                        }
                    }
                }
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
        ) {
            // Status Feedback Bar
            AnimatedVisibility(visible = statusMessage != null) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(NoviqSurfaceVariant)
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = statusMessage ?: "",
                        fontSize = 12.sp,
                        color = NoviqCyan,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(
                        onClick = { viewModel.clearStatus() },
                        modifier = Modifier.size(24.dp)
                    ) {
                        Text("✕", color = NoviqTextSecondary, fontSize = 12.sp)
                    }
                }
            }

            // Image Preview Canvas
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(300.dp)
                    .background(Color.Black)
                    .testTag("photo_preview_container"),
                contentAlignment = Alignment.Center
            ) {
                val displayBmp = if (isComparingBefore) originalBitmap else editedBitmap

                if (displayBmp != null) {
                    Image(
                        bitmap = displayBmp.asImageBitmap(),
                        contentDescription = "Photo Preview",
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(8.dp)
                            .pointerInput(Unit) {
                                detectTapGestures(
                                    onPress = {
                                        viewModel.isComparingBefore.value = true
                                        tryAwaitRelease()
                                        viewModel.isComparingBefore.value = false
                                    }
                                )
                            },
                        contentScale = ContentScale.Fit
                    )

                    // Before / After Indicator Badge
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color.Black.copy(alpha = 0.7f),
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(12.dp)
                    ) {
                        Text(
                            text = if (isComparingBefore) "Original (Hold)" else "Hold to Compare Before",
                            fontSize = 11.sp,
                            color = if (isComparingBefore) NoviqCyan else Color.White,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                } else {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                        modifier = Modifier
                            .fillMaxSize()
                            .clickable {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            }
                    ) {
                        Box(
                            modifier = Modifier
                                .size(56.dp)
                                .clip(CircleShape)
                                .background(NoviqSurfaceVariant),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AddPhotoAlternate,
                                contentDescription = null,
                                tint = NoviqCyan,
                                modifier = Modifier.size(30.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = "Select a Photo to Edit",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = NoviqTextPrimary
                        )
                        Text(
                            text = "Supports JPEG, PNG, WEBP from Gallery",
                            fontSize = 12.sp,
                            color = NoviqTextSecondary
                        )
                    }
                }

                if (isProcessing) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = 0.4f)),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(color = NoviqCyan)
                    }
                }
            }

            if (editedBitmap != null) {
                // Tool Category Tabs
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(NoviqSurface)
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    FilterChip(
                        selected = activeTab == "adjust",
                        onClick = { activeTab = "adjust" },
                        label = { Text("Adjustments") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = NoviqCyan,
                            selectedLabelColor = Color.Black
                        )
                    )
                    FilterChip(
                        selected = activeTab == "ai",
                        onClick = { activeTab = "ai" },
                        label = { Text("AI Tools") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = NoviqCyan,
                            selectedLabelColor = Color.Black
                        )
                    )
                    FilterChip(
                        selected = activeTab == "crop",
                        onClick = { activeTab = "crop" },
                        label = { Text("Crop & Rotate") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = NoviqCyan,
                            selectedLabelColor = Color.Black
                        )
                    )
                }

                // Controls Panel
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    when (activeTab) {
                        "adjust" -> {
                            // Brightness
                            Column {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("Brightness", fontSize = 13.sp, color = NoviqTextSecondary)
                                    Text("${params.brightness.toInt()}", fontSize = 13.sp, color = NoviqCyan)
                                }
                                Slider(
                                    value = params.brightness,
                                    onValueChange = { viewModel.updateBrightness(it) },
                                    valueRange = -100f..100f,
                                    colors = SliderDefaults.colors(
                                        thumbColor = NoviqCyan,
                                        activeTrackColor = NoviqCyan
                                    )
                                )
                            }

                            // Contrast
                            Column {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("Contrast", fontSize = 13.sp, color = NoviqTextSecondary)
                                    Text("${(params.contrast * 100).toInt()}%", fontSize = 13.sp, color = NoviqCyan)
                                }
                                Slider(
                                    value = params.contrast,
                                    onValueChange = { viewModel.updateContrast(it) },
                                    valueRange = 0.5f..2.0f,
                                    colors = SliderDefaults.colors(
                                        thumbColor = NoviqCyan,
                                        activeTrackColor = NoviqCyan
                                    )
                                )
                            }

                            // Saturation
                            Column {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("Saturation", fontSize = 13.sp, color = NoviqTextSecondary)
                                    Text("${(params.saturation * 100).toInt()}%", fontSize = 13.sp, color = NoviqCyan)
                                }
                                Slider(
                                    value = params.saturation,
                                    onValueChange = { viewModel.updateSaturation(it) },
                                    valueRange = 0.0f..2.0f,
                                    colors = SliderDefaults.colors(
                                        thumbColor = NoviqCyan,
                                        activeTrackColor = NoviqCyan
                                    )
                                )
                            }

                            // Quick Filter Buttons
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Button(
                                    onClick = { viewModel.toggleEnhance() },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (params.isEnhanced) NoviqCyan else NoviqSurfaceVariant,
                                        contentColor = if (params.isEnhanced) Color.Black else NoviqTextPrimary
                                    ),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text(if (params.isEnhanced) "Enhanced ✓" else "Enhance")
                                }

                                Button(
                                    onClick = { viewModel.toggleBlur() },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (params.isBlurred) NoviqCyan else NoviqSurfaceVariant,
                                        contentColor = if (params.isBlurred) Color.Black else NoviqTextPrimary
                                    ),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text(if (params.isBlurred) "Blur On ✓" else "Blur BG")
                                }
                            }
                        }

                        "ai" -> {
                            Text(
                                text = "AI Edit Instruction",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = NoviqTextPrimary
                            )

                            OutlinedTextField(
                                value = aiInstruction,
                                onValueChange = { viewModel.aiInstruction.value = it },
                                placeholder = { Text("e.g. 'Remove background', 'Enhance portrait contrast', 'Cinematic glow'") },
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = NoviqCyan,
                                    unfocusedBorderColor = NoviqSurfaceBorder,
                                    focusedTextColor = NoviqTextPrimary,
                                    unfocusedTextColor = NoviqTextPrimary,
                                    focusedContainerColor = NoviqSurfaceVariant,
                                    unfocusedContainerColor = NoviqSurfaceVariant
                                ),
                                shape = RoundedCornerShape(12.dp)
                            )

                            Button(
                                onClick = { viewModel.applyAiInstruction() },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = NoviqCyan,
                                    contentColor = Color.Black
                                ),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("apply_ai_instruction_button")
                            ) {
                                Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Apply AI Edit", fontWeight = FontWeight.Bold)
                            }

                            Text(
                                text = "Noviq AI interprets instructions and applies optimized visual curves, subject isolation masks, and enhancement algorithms.",
                                fontSize = 12.sp,
                                color = NoviqTextSecondary,
                                lineHeight = 16.sp
                            )
                        }

                        "crop" -> {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedButton(
                                    onClick = { viewModel.crop("1:1") },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("1:1", color = NoviqCyan)
                                }
                                OutlinedButton(
                                    onClick = { viewModel.crop("4:3") },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("4:3", color = NoviqCyan)
                                }
                                OutlinedButton(
                                    onClick = { viewModel.crop("16:9") },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("16:9", color = NoviqCyan)
                                }
                            }

                            Button(
                                onClick = { viewModel.rotate90() },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = NoviqSurfaceVariant,
                                    contentColor = NoviqTextPrimary
                                ),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.AutoMirrored.Filled.RotateRight, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Rotate 90° Clockwise")
                            }
                        }
                    }

                    // Reset Button
                    OutlinedButton(
                        onClick = { viewModel.resetEdits() },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null, tint = NoviqError)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Reset to Original", color = NoviqError)
                    }
                }
            }
        }
    }
}
