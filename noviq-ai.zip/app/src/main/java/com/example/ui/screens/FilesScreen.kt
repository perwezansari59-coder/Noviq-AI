package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.SavedDocumentEntity
import com.example.ui.theme.NoviqBackground
import com.example.ui.theme.NoviqBlue
import com.example.ui.theme.NoviqCyan
import com.example.ui.theme.NoviqError
import com.example.ui.theme.NoviqSurface
import com.example.ui.theme.NoviqSurfaceBorder
import com.example.ui.theme.NoviqSurfaceVariant
import com.example.ui.theme.NoviqTextPrimary
import com.example.ui.theme.NoviqTextSecondary
import com.example.ui.viewmodels.FilesViewModel

@Composable
fun FilesScreen(viewModel: FilesViewModel) {
    val context = LocalContext.current
    val allDocuments by viewModel.allDocuments.collectAsState()
    val selectedDocument by viewModel.selectedDocument.collectAsState()
    val isProcessing by viewModel.isProcessing.collectAsState()
    val qaResult by viewModel.qaResult.collectAsState()
    val statusMessage by viewModel.statusMessage.collectAsState()
    val questionText by viewModel.questionText.collectAsState()

    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        viewModel.onDocumentSelected(uri)
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .testTag("files_screen"),
        containerColor = NoviqBackground,
        topBar = {
            Surface(
                color = NoviqSurface,
                border = androidx.compose.foundation.BorderStroke(1.dp, NoviqSurfaceBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Document AI",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = NoviqTextPrimary
                        )
                        Text(
                            text = "Summarize & Ask Questions on Docs",
                            fontSize = 11.sp,
                            color = NoviqCyan
                        )
                    }

                    Button(
                        onClick = {
                            filePickerLauncher.launch(
                                arrayOf(
                                    "text/plain",
                                    "text/csv",
                                    "application/json",
                                    "text/markdown",
                                    "*/*"
                                )
                            )
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = NoviqCyan,
                            contentColor = Color.Black
                        ),
                        shape = RoundedCornerShape(20.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                        modifier = Modifier.testTag("import_file_button")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Add File", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // Status Banner
            AnimatedVisibility(visible = statusMessage != null) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(NoviqSurfaceVariant)
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = statusMessage ?: "",
                        fontSize = 12.sp,
                        color = NoviqCyan,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(
                        onClick = { viewModel.clearStatus() },
                        modifier = Modifier.size(24.dp)
                    ) {
                        Text("✕", color = NoviqTextSecondary, fontSize = 12.sp)
                    }
                }
            }

            if (selectedDocument == null) {
                // List of Saved Documents or Upload prompt
                if (allDocuments.isEmpty()) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(NoviqBlue.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Description,
                                contentDescription = null,
                                tint = NoviqCyan,
                                modifier = Modifier.size(32.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Text(
                            text = "No Documents Imported Yet",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = NoviqTextPrimary
                        )

                        Text(
                            text = "Import a text, CSV, markdown or code file from your device storage to generate executive summaries and ask interactive questions.",
                            fontSize = 13.sp,
                            color = NoviqTextSecondary,
                            modifier = Modifier.padding(top = 8.dp, start = 16.dp, end = 16.dp),
                            lineHeight = 18.sp
                        )

                        Spacer(modifier = Modifier.height(20.dp))

                        Button(
                            onClick = {
                                filePickerLauncher.launch(
                                    arrayOf("text/plain", "text/csv", "application/json", "*/*")
                                )
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = NoviqCyan,
                                contentColor = Color.Black
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Select Document", fontWeight = FontWeight.Bold)
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        item {
                            Text(
                                text = "Your Imported Documents",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = NoviqTextPrimary
                            )
                        }

                        items(allDocuments) { doc ->
                            DocumentListItem(
                                doc = doc,
                                onClick = { viewModel.selectDocument(doc) },
                                onDelete = { viewModel.deleteDocument(doc.id) }
                            )
                        }
                    }
                }
            } else {
                // Selected Document Detail & AI View
                val doc = selectedDocument!!
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Document Header Card
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = NoviqSurface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, NoviqSurfaceBorder)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(CircleShape)
                                        .background(NoviqBlue.copy(alpha = 0.2f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Description,
                                        contentDescription = null,
                                        tint = NoviqCyan,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }

                                Column {
                                    Text(
                                        text = doc.name,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = NoviqTextPrimary
                                    )
                                    Text(
                                        text = "${doc.sizeBytes / 1024} KB • ${doc.extractedText.length} characters",
                                        fontSize = 12.sp,
                                        color = NoviqTextSecondary
                                    )
                                }
                            }

                            TextButton(onClick = { viewModel.clearSelected() }) {
                                Text("Back", color = NoviqCyan)
                            }
                        }
                    }

                    // Summarize Button
                    Button(
                        onClick = { viewModel.summarizeSelected() },
                        enabled = !isProcessing,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = NoviqCyan,
                            contentColor = Color.Black
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("summarize_doc_button")
                    ) {
                        if (isProcessing && doc.summary.isBlank()) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                color = Color.Black,
                                strokeWidth = 2.dp
                            )
                        } else {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Generate AI Summary", fontWeight = FontWeight.Bold)
                        }
                    }

                    // Display AI Summary if present
                    if (doc.summary.isNotBlank()) {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = NoviqSurface),
                            border = androidx.compose.foundation.BorderStroke(1.dp, NoviqCyan.copy(alpha = 0.4f))
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "AI Executive Summary",
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = NoviqCyan
                                    )

                                    Row {
                                        IconButton(
                                            onClick = {
                                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                                clipboard.setPrimaryClip(ClipData.newPlainText("Noviq AI Summary", doc.summary))
                                                Toast.makeText(context, "Summary copied to clipboard", Toast.LENGTH_SHORT).show()
                                            }
                                        ) {
                                            Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = NoviqTextSecondary, modifier = Modifier.size(18.dp))
                                        }

                                        IconButton(
                                            onClick = {
                                                val intent = Intent(Intent.ACTION_SEND).apply {
                                                    type = "text/plain"
                                                    putExtra(Intent.EXTRA_TEXT, doc.summary)
                                                }
                                                context.startActivity(Intent.createChooser(intent, "Share Document Summary"))
                                            }
                                        ) {
                                            Icon(Icons.Default.Share, contentDescription = "Share", tint = NoviqTextSecondary, modifier = Modifier.size(18.dp))
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                Text(
                                    text = doc.summary,
                                    fontSize = 13.sp,
                                    color = NoviqTextPrimary,
                                    lineHeight = 20.sp
                                )
                            }
                        }
                    }

                    // Interactive Document Q&A
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = NoviqSurface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, NoviqSurfaceBorder)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "Ask Questions About Document",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = NoviqTextPrimary
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedTextField(
                                    value = questionText,
                                    onValueChange = { viewModel.questionText.value = it },
                                    placeholder = { Text("Ask anything from this doc...", fontSize = 13.sp) },
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = NoviqCyan,
                                        unfocusedBorderColor = NoviqSurfaceBorder,
                                        focusedTextColor = NoviqTextPrimary,
                                        unfocusedTextColor = NoviqTextPrimary,
                                        focusedContainerColor = NoviqSurfaceVariant,
                                        unfocusedContainerColor = NoviqSurfaceVariant
                                    ),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.weight(1f)
                                )

                                IconButton(
                                    onClick = { viewModel.askQuestion() },
                                    enabled = !isProcessing && questionText.isNotBlank(),
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clip(CircleShape)
                                        .background(
                                            if (questionText.isNotBlank()) NoviqCyan else NoviqSurfaceVariant
                                        )
                                ) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.Send,
                                        contentDescription = "Ask",
                                        tint = if (questionText.isNotBlank()) Color.Black else NoviqTextSecondary
                                    )
                                }
                            }

                            if (qaResult != null) {
                                Spacer(modifier = Modifier.height(14.dp))
                                Text(
                                    text = "Answer:",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = NoviqCyan
                                )
                                Text(
                                    text = qaResult ?: "",
                                    fontSize = 13.sp,
                                    color = NoviqTextPrimary,
                                    modifier = Modifier.padding(top = 4.dp),
                                    lineHeight = 18.sp
                                )
                            }
                        }
                    }

                    // Extracted Content Preview
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = NoviqSurfaceVariant)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = "Extracted Plain Text (First 500 chars)",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = NoviqTextSecondary
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = doc.extractedText.take(500) + if (doc.extractedText.length > 500) "..." else "",
                                fontSize = 12.sp,
                                color = NoviqTextSecondary,
                                lineHeight = 16.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DocumentListItem(
    doc: SavedDocumentEntity,
    onClick: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = NoviqSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, NoviqSurfaceBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(NoviqBlue.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Description,
                        contentDescription = null,
                        tint = NoviqCyan,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Column {
                    Text(
                        text = doc.name,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = NoviqTextPrimary,
                        maxLines = 1
                    )
                    Text(
                        text = if (doc.summary.isNotBlank()) "Summary available ✓" else "${doc.extractedText.length} characters",
                        fontSize = 11.sp,
                        color = if (doc.summary.isNotBlank()) NoviqCyan else NoviqTextSecondary
                    )
                }
            }

            IconButton(onClick = onDelete) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "Delete",
                    tint = NoviqTextSecondary,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}
