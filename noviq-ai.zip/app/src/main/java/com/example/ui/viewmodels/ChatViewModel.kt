package com.example.ui.viewmodels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.ChatMessageEntity
import com.example.data.local.ChatSessionEntity
import com.example.data.repository.GeminiChatRepository
import com.example.data.repository.GenerationState
import com.example.service.SpeechRecognitionHelper
import com.example.service.SpeechState
import com.example.service.TextToSpeechHelper
import com.example.service.TtsState
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class ChatViewModel(
    private val chatRepository: GeminiChatRepository,
    private val speechHelper: SpeechRecognitionHelper,
    private val ttsHelper: TextToSpeechHelper
) : ViewModel() {

    val allSessions: StateFlow<List<ChatSessionEntity>> = chatRepository.allSessions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _currentSessionId = MutableStateFlow<String?>(null)
    val currentSessionId: StateFlow<String?> = _currentSessionId

    val currentMessages: StateFlow<List<ChatMessageEntity>> = _currentSessionId
        .flatMapLatest { id ->
            if (id != null) chatRepository.getMessagesForSession(id)
            else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val generationState: StateFlow<GenerationState> = chatRepository.generationState
    val speechState: StateFlow<SpeechState> = speechHelper.speechState
    val ttsState: StateFlow<TtsState> = ttsHelper.ttsState

    val promptText = MutableStateFlow("")
    val selectedVoiceLanguage = MutableStateFlow("en-IN") // "en-IN", "hi-IN", "en-US"

    init {
        viewModelScope.launch {
            allSessions.collect { sessions ->
                if (_currentSessionId.value == null && sessions.isNotEmpty()) {
                    _currentSessionId.value = sessions.first().id
                }
            }
        }

        // Listen to voice recognition updates and append/put into input text
        viewModelScope.launch {
            speechHelper.speechState.collect { state ->
                if (state is SpeechState.Success && state.text.isNotBlank()) {
                    val current = promptText.value.trim()
                    if (current.isEmpty()) {
                        promptText.value = state.text
                    } else {
                        promptText.value = "$current ${state.text}"
                    }
                }
            }
        }
    }

    fun selectSession(sessionId: String) {
        ttsHelper.stop()
        speechHelper.stopListening()
        _currentSessionId.value = sessionId
    }

    fun startNewChat(userId: String = "local_user") {
        ttsHelper.stop()
        speechHelper.stopListening()
        viewModelScope.launch {
            val newId = chatRepository.createNewSession(userId)
            _currentSessionId.value = newId
            promptText.value = ""
        }
    }

    fun deleteSession(sessionId: String) {
        viewModelScope.launch {
            chatRepository.deleteSession(sessionId)
            if (_currentSessionId.value == sessionId) {
                _currentSessionId.value = allSessions.value.firstOrNull { it.id != sessionId }?.id
            }
        }
    }

    fun clearAllChats() {
        ttsHelper.stop()
        speechHelper.stopListening()
        viewModelScope.launch {
            chatRepository.clearAllChats()
            _currentSessionId.value = null
            promptText.value = ""
        }
    }

    fun sendCurrentPrompt(overridePrompt: String? = null) {
        if (generationState.value is GenerationState.Generating) {
            return
        }
        val rawText = overridePrompt ?: promptText.value
        val text = rawText.trim()
        if (text.isBlank()) return

        promptText.value = ""

        viewModelScope.launch {
            val sessionId = _currentSessionId.value ?: chatRepository.createNewSession().also {
                _currentSessionId.value = it
            }

            chatRepository.sendMessage(
                scope = viewModelScope,
                sessionId = sessionId,
                userPrompt = text
            )
        }
    }

    fun stopGeneration() {
        chatRepository.stopGeneration()
    }

    fun retryLastMessage() {
        val lastUserMsg = currentMessages.value.lastOrNull { it.role == "user" }?.content ?: return
        val sessionId = _currentSessionId.value ?: return
        viewModelScope.launch {
            chatRepository.retryMessage(
                scope = viewModelScope,
                sessionId = sessionId,
                lastUserMessage = lastUserMsg
            )
        }
    }

    // Voice recognition functions
    fun startListening() {
        speechHelper.startListening(selectedVoiceLanguage.value)
    }

    fun stopListening() {
        speechHelper.stopListening()
    }

    fun resetSpeechState() {
        speechHelper.resetState()
    }

    // Text-to-Speech functions
    fun speakResponse(messageId: String, content: String) {
        ttsHelper.speak(messageId, content)
    }

    fun pauseTts() {
        ttsHelper.pause()
    }

    fun resumeTts() {
        ttsHelper.resume()
    }

    fun stopTts() {
        ttsHelper.stop()
    }

    override fun onCleared() {
        super.onCleared()
        speechHelper.stopListening()
        ttsHelper.stop()
    }
}
