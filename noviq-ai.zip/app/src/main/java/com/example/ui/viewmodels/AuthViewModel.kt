package com.example.ui.viewmodels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.repository.AuthRepository
import com.example.data.repository.AuthResult
import com.example.data.repository.AuthUserState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

sealed class AuthUiState {
    object Idle : AuthUiState()
    object Loading : AuthUiState()
    data class Error(val message: String) : AuthUiState()
    object Authenticated : AuthUiState()
}

class AuthViewModel(private val authRepository: AuthRepository) : ViewModel() {
    val currentUser: StateFlow<AuthUserState> = authRepository.currentUser

    private val _uiState = MutableStateFlow<AuthUiState>(AuthUiState.Idle)
    val uiState: StateFlow<AuthUiState> = _uiState

    fun login(email: String, pass: String) {
        viewModelScope.launch {
            _uiState.value = AuthUiState.Loading
            when (val res = authRepository.login(email, pass)) {
                is AuthResult.Success -> _uiState.value = AuthUiState.Authenticated
                is AuthResult.Error -> _uiState.value = AuthUiState.Error(res.message)
            }
        }
    }

    fun signup(email: String, pass: String) {
        viewModelScope.launch {
            _uiState.value = AuthUiState.Loading
            when (val res = authRepository.signup(email, pass)) {
                is AuthResult.Success -> _uiState.value = AuthUiState.Authenticated
                is AuthResult.Error -> _uiState.value = AuthUiState.Error(res.message)
            }
        }
    }

    fun loginGuest() {
        authRepository.loginGuest()
        _uiState.value = AuthUiState.Authenticated
    }

    fun logout() {
        authRepository.logout()
        _uiState.value = AuthUiState.Idle
    }

    fun clearError() {
        _uiState.value = AuthUiState.Idle
    }
}
