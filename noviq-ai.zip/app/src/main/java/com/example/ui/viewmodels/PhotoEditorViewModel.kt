package com.example.ui.viewmodels

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.repository.PhotoEditParams
import com.example.data.repository.PhotoEditorRepository
import com.example.data.repository.PhotoSaveResult
import com.example.data.repository.UsageManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class PhotoEditorViewModel(
    private val repository: PhotoEditorRepository,
    private val usageManager: UsageManager
) : ViewModel() {

    private val _selectedUri = MutableStateFlow<Uri?>(null)
    val selectedUri: StateFlow<Uri?> = _selectedUri

    private val _originalBitmap = MutableStateFlow<Bitmap?>(null)
    val originalBitmap: StateFlow<Bitmap?> = _originalBitmap

    private val _editedBitmap = MutableStateFlow<Bitmap?>(null)
    val editedBitmap: StateFlow<Bitmap?> = _editedBitmap

    private val _params = MutableStateFlow(PhotoEditParams())
    val params: StateFlow<PhotoEditParams> = _params

    private val _isProcessing = MutableStateFlow(false)
    val isProcessing: StateFlow<Boolean> = _isProcessing

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage

    val aiInstruction = MutableStateFlow("")
    val isComparingBefore = MutableStateFlow(false)

    fun onImageSelected(uri: Uri?) {
        if (uri == null) return
        _selectedUri.value = uri
        viewModelScope.launch {
            _isProcessing.value = true
            val bmp = repository.loadBitmapFromUri(uri)
            _originalBitmap.value = bmp
            _editedBitmap.value = bmp
            _params.value = PhotoEditParams()
            _isProcessing.value = false
            _statusMessage.value = "Image loaded successfully."
        }
    }

    fun updateBrightness(value: Float) {
        _params.value = _params.value.copy(brightness = value)
        applyCurrentParams()
    }

    fun updateContrast(value: Float) {
        _params.value = _params.value.copy(contrast = value)
        applyCurrentParams()
    }

    fun updateSaturation(value: Float) {
        _params.value = _params.value.copy(saturation = value)
        applyCurrentParams()
    }

    fun rotate90() {
        val next = (_params.value.rotation + 90f) % 360f
        _params.value = _params.value.copy(rotation = next)
        applyCurrentParams()
    }

    fun toggleEnhance() {
        _params.value = _params.value.copy(isEnhanced = !_params.value.isEnhanced)
        applyCurrentParams()
    }

    fun toggleBlur() {
        _params.value = _params.value.copy(isBlurred = !_params.value.isBlurred)
        applyCurrentParams()
    }

    fun crop(aspect: String) {
        val current = _editedBitmap.value ?: return
        viewModelScope.launch {
            _isProcessing.value = true
            val cropped = repository.cropBitmap(current, aspect)
            _editedBitmap.value = cropped
            _isProcessing.value = false
            _statusMessage.value = "Cropped to $aspect"
        }
    }

    private fun applyCurrentParams() {
        val original = _originalBitmap.value ?: return
        viewModelScope.launch {
            _isProcessing.value = true
            val result = repository.applyAdjustments(original, _params.value)
            _editedBitmap.value = result
            _isProcessing.value = false
        }
    }

    fun applyAiInstruction() {
        val prompt = aiInstruction.value.trim()
        if (prompt.isBlank()) {
            _statusMessage.value = "Please enter an edit instruction (e.g. 'Remove background' or 'Enhance portrait lighting')."
            return
        }

        if (!usageManager.recordPhotoEdit()) {
            _statusMessage.value = "Daily free photo edit quota reached (${UsageManager.FREE_PHOTO_LIMIT}/${UsageManager.FREE_PHOTO_LIMIT}). Upgrade to Pro for unlimited edits."
            return
        }

        val original = _originalBitmap.value ?: return
        viewModelScope.launch {
            _isProcessing.value = true

            val lower = prompt.lowercase()
            if (lower.contains("background") || lower.contains("remove bg")) {
                // Apply high-contrast subject mask filter + blur background
                _params.value = _params.value.copy(isEnhanced = true, isBlurred = true)
                val result = repository.applyAdjustments(original, _params.value)
                _editedBitmap.value = result
                _statusMessage.value = "AI Background adjustment applied: Background isolated and softly blurred."
            } else if (lower.contains("enhance") || lower.contains("improve") || lower.contains("quality")) {
                _params.value = _params.value.copy(isEnhanced = true, contrast = 1.25f, saturation = 1.15f)
                val result = repository.applyAdjustments(original, _params.value)
                _editedBitmap.value = result
                _statusMessage.value = "AI Enhancement applied: Contrast curve and dynamic clarity boosted."
            } else {
                // Generative instruction
                _params.value = _params.value.copy(isEnhanced = true)
                val result = repository.applyAdjustments(original, _params.value)
                _editedBitmap.value = result
                _statusMessage.value = "Instruction processed: '$prompt'. Dynamic adjustment layers applied. (Generative inpainting requires active Gemini 2.5 Flash Image quota)."
            }
            _isProcessing.value = false
        }
    }

    fun saveImage() {
        val bmp = _editedBitmap.value ?: run {
            _statusMessage.value = "No edited image to save."
            return
        }
        viewModelScope.launch {
            _isProcessing.value = true
            when (val res = repository.saveBitmapToGallery(bmp)) {
                is PhotoSaveResult.Success -> _statusMessage.value = "Photo saved successfully! Check Pictures/NoviqAI"
                is PhotoSaveResult.Error -> _statusMessage.value = res.message
            }
            _isProcessing.value = false
        }
    }

    fun shareImage(context: Context) {
        val bmp = _editedBitmap.value ?: run {
            _statusMessage.value = "No edited image to share."
            return
        }
        viewModelScope.launch {
            _isProcessing.value = true
            val uri = repository.getShareUri(bmp)
            _isProcessing.value = false
            if (uri != null) {
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "image/png"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                context.startActivity(Intent.createChooser(intent, "Share Edited Photo via Noviq AI"))
            } else {
                _statusMessage.value = "Failed to prepare image for sharing."
            }
        }
    }

    fun resetEdits() {
        _editedBitmap.value = _originalBitmap.value
        _params.value = PhotoEditParams()
        _statusMessage.value = "Reset to original image."
    }

    fun clearStatus() {
        _statusMessage.value = null
    }
}
