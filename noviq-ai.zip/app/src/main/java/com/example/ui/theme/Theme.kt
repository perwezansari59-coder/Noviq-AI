package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val NoviqDarkColorScheme = darkColorScheme(
  primary = NoviqCyan,
  onPrimary = Color(0xFF00363D),
  primaryContainer = NoviqCyanDim,
  onPrimaryContainer = Color.White,
  secondary = NoviqViolet,
  onSecondary = Color.White,
  secondaryContainer = NoviqVioletDark,
  onSecondaryContainer = Color(0xFFE9DDFF),
  tertiary = NoviqBlue,
  onTertiary = Color.White,
  background = NoviqBackground,
  onBackground = NoviqTextPrimary,
  surface = NoviqSurface,
  onSurface = NoviqTextPrimary,
  surfaceVariant = NoviqSurfaceVariant,
  onSurfaceVariant = NoviqTextSecondary,
  outline = NoviqSurfaceBorder,
  error = NoviqError,
  onError = Color.White
)

@Composable
fun NoviqTheme(
  content: @Composable () -> Unit
) {
  MaterialTheme(
    colorScheme = NoviqDarkColorScheme,
    typography = Typography,
    content = content
  )
}

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true,
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit
) {
  NoviqTheme(content = content)
}

