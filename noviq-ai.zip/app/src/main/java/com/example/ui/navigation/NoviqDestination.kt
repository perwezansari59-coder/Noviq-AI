package com.example.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Settings
import androidx.compose.ui.graphics.vector.ImageVector

enum class NoviqDestination(
    val route: String,
    val title: String,
    val icon: ImageVector
) {
    HOME("home", "Home", Icons.Default.Home),
    CHAT("chat", "Chat", Icons.Default.ChatBubble),
    PHOTO_EDITOR("photo_editor", "Photo AI", Icons.Default.Image),
    FILES("files", "Files", Icons.Default.Description),
    SETTINGS("settings", "Settings", Icons.Default.Settings);

    companion object {
        val bottomNavItems = listOf(HOME, CHAT, PHOTO_EDITOR, FILES, SETTINGS)
    }
}
