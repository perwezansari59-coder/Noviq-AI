package com.example.ui.navigation

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.di.AppContainer
import com.example.ui.components.UpgradeSubscriptionDialog
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.ChatScreen
import com.example.ui.screens.FilesScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.PhotoEditorScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.NoviqCyan
import com.example.ui.theme.NoviqSurface
import com.example.ui.theme.NoviqSurfaceBorder
import com.example.ui.theme.NoviqTextPrimary
import com.example.ui.theme.NoviqTextSecondary
import com.example.ui.viewmodels.AuthViewModel
import com.example.ui.viewmodels.BillingViewModel
import com.example.ui.viewmodels.ChatViewModel
import com.example.ui.viewmodels.FilesViewModel
import com.example.ui.viewmodels.PhotoEditorViewModel
import com.example.ui.viewmodels.SettingsViewModel

@Composable
fun NoviqAppNavHost(container: AppContainer) {
    val navController = rememberNavController()
    val authViewModel = remember { AuthViewModel(container.authRepository) }
    val billingViewModel = remember { BillingViewModel(container.billingRepository) }
    val chatViewModel = remember {
        ChatViewModel(container.chatRepository, container.speechHelper, container.ttsHelper)
    }
    val photoViewModel = remember {
        PhotoEditorViewModel(container.photoEditorRepository, container.usageManager)
    }
    val filesViewModel = remember {
        FilesViewModel(container.documentRepository)
    }
    val settingsViewModel = remember {
        SettingsViewModel(
            container.authRepository,
            container.billingRepository,
            container.usageManager,
            container.chatRepository,
            container.ttsHelper
        )
    }

    val currentUser by authViewModel.currentUser.collectAsState()
    val usage by container.usageManager.usage.collectAsState()
    val isPremium by container.billingRepository.isPremium.collectAsState()

    var showUpgradeDialog by remember { mutableStateOf(false) }

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    if (showUpgradeDialog) {
        UpgradeSubscriptionDialog(
            viewModel = billingViewModel,
            onDismiss = { showUpgradeDialog = false }
        )
    }

    Scaffold(
        bottomBar = {
            AnimatedVisibility(visible = currentUser.isLoggedIn && currentRoute != "auth") {
                NavigationBar(
                    containerColor = NoviqSurface,
                    tonalElevation = 8.dp
                ) {
                    NoviqDestination.bottomNavItems.forEach { destination ->
                        val selected = currentRoute == destination.route
                        NavigationBarItem(
                            selected = selected,
                            onClick = {
                                navController.navigate(destination.route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = {
                                Icon(
                                    imageVector = destination.icon,
                                    contentDescription = destination.title
                                )
                            },
                            label = {
                                Text(
                                    text = destination.title,
                                    fontSize = 11.sp
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Color.Black,
                                selectedTextColor = NoviqCyan,
                                indicatorColor = NoviqCyan,
                                unselectedIconColor = NoviqTextSecondary,
                                unselectedTextColor = NoviqTextSecondary
                            ),
                            modifier = Modifier.testTag("nav_${destination.route}")
                        )
                    }
                }
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            NavHost(
                navController = navController,
                startDestination = if (currentUser.isLoggedIn) NoviqDestination.HOME.route else "auth"
            ) {
                composable("auth") {
                    AuthScreen(
                        viewModel = authViewModel,
                        onAuthSuccess = {
                            navController.navigate(NoviqDestination.HOME.route) {
                                popUpTo("auth") { inclusive = true }
                            }
                        }
                    )
                }

                composable(NoviqDestination.HOME.route) {
                    HomeScreen(
                        usage = usage,
                        isPremium = isPremium,
                        onNavigateToChat = { prompt ->
                            if (!prompt.isNullOrBlank()) {
                                chatViewModel.promptText.value = prompt
                            }
                            navController.navigate(NoviqDestination.CHAT.route)
                        },
                        onNavigateToPhotoEditor = {
                            navController.navigate(NoviqDestination.PHOTO_EDITOR.route)
                        },
                        onNavigateToFiles = {
                            navController.navigate(NoviqDestination.FILES.route)
                        },
                        onNavigateToVoice = {
                            navController.navigate(NoviqDestination.CHAT.route)
                            chatViewModel.startListening()
                        },
                        onNavigateToSettings = {
                            navController.navigate(NoviqDestination.SETTINGS.route)
                        },
                        onUpgradeClick = {
                            showUpgradeDialog = true
                        }
                    )
                }

                composable(NoviqDestination.CHAT.route) {
                    ChatScreen(
                        viewModel = chatViewModel
                    )
                }

                composable(NoviqDestination.PHOTO_EDITOR.route) {
                    PhotoEditorScreen(
                        viewModel = photoViewModel
                    )
                }

                composable(NoviqDestination.FILES.route) {
                    FilesScreen(
                        viewModel = filesViewModel
                    )
                }

                composable(NoviqDestination.SETTINGS.route) {
                    SettingsScreen(
                        viewModel = settingsViewModel,
                        onUpgradeClick = { showUpgradeDialog = true },
                        onLoggedOut = {
                            navController.navigate("auth") {
                                popUpTo(0) { inclusive = true }
                            }
                        }
                    )
                }
            }
        }
    }
}
