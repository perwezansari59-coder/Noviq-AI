package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Noviq AI Modern Dark Palette
val NoviqBackground = Color(0xFF090C15)
val NoviqSurface = Color(0xFF111726)
val NoviqSurfaceVariant = Color(0xFF192238)
val NoviqSurfaceBorder = Color(0xFF263352)

// Primary Neon Cyan & Electric Blue
val NoviqCyan = Color(0xFF00E5FF)
val NoviqCyanDim = Color(0xFF00B4D8)
val NoviqBlue = Color(0xFF2979FF)

// Secondary & Accent Luminous Violet
val NoviqViolet = Color(0xFF8C52FF)
val NoviqVioletDark = Color(0xFF5B21B6)

// Text Colors
val NoviqTextPrimary = Color(0xFFF1F5F9)
val NoviqTextSecondary = Color(0xFF94A3B8)
val NoviqTextTertiary = Color(0xFF64748B)

// Status Colors
val NoviqSuccess = Color(0xFF10B981)
val NoviqWarning = Color(0xFFF59E0B)
val NoviqError = Color(0xFFEF4444)
val NoviqGold = Color(0xFFFFB703)

