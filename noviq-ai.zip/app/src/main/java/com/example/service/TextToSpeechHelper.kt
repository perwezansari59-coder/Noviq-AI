package com.example.service

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.Locale

sealed class TtsState {
    object Idle : TtsState()
    data class Speaking(val messageId: String) : TtsState()
    data class Paused(val messageId: String) : TtsState()
    data class Error(val message: String) : TtsState()
}

class TextToSpeechHelper(private val context: Context) : TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var isInitialized = false

    private val _ttsState = MutableStateFlow<TtsState>(TtsState.Idle)
    val ttsState: StateFlow<TtsState> = _ttsState

    private var currentSpeakingText: String = ""
    private var currentMessageId: String = ""
    private var currentPitch: Float = 1.0f
    private var currentSpeed: Float = 1.0f
    private var currentLanguageCode: String = "en" // "en", "hi", or "auto"

    init {
        tts = TextToSpeech(context.applicationContext, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isInitialized = true
            setupLanguage(currentLanguageCode)
            tts?.setPitch(currentPitch)
            tts?.setSpeechRate(currentSpeed)

            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    _ttsState.value = TtsState.Speaking(currentMessageId)
                }

                override fun onDone(utteranceId: String?) {
                    _ttsState.value = TtsState.Idle
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    _ttsState.value = TtsState.Error("Failed to speak text via Text-to-Speech")
                }

                override fun onError(utteranceId: String?, errorCode: Int) {
                    _ttsState.value = TtsState.Error("TTS Error (code $errorCode)")
                }
            })
        } else {
            isInitialized = false
            _ttsState.value = TtsState.Error("TTS Engine initialization failed on this device.")
        }
    }

    fun setSpeechParameters(pitch: Float, speed: Float, language: String) {
        currentPitch = pitch
        currentSpeed = speed
        currentLanguageCode = language
        if (isInitialized) {
            tts?.setPitch(pitch)
            tts?.setSpeechRate(speed)
            setupLanguage(language)
        }
    }

    private fun setupLanguage(languageCode: String) {
        val hindiLocale = Locale.Builder().setLanguage("hi").setRegion("IN").build()
        val locale = when (languageCode) {
            "hi" -> hindiLocale
            "en" -> Locale.US
            else -> {
                // Auto/Hinglish: Try Hindi if supported, else default
                if (tts?.isLanguageAvailable(hindiLocale) == TextToSpeech.LANG_AVAILABLE ||
                    tts?.isLanguageAvailable(hindiLocale) == TextToSpeech.LANG_COUNTRY_AVAILABLE) {
                    hindiLocale
                } else {
                    Locale.US
                }
            }
        }
        val result = tts?.setLanguage(locale)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            // fallback to English
            tts?.setLanguage(Locale.US)
        }
    }

    fun speak(messageId: String, text: String) {
        if (!isInitialized) {
            _ttsState.value = TtsState.Error("TTS engine is still initializing...")
            return
        }

        // Clean markdown characters for pleasant speech output
        val cleanText = text
            .replace(Regex("[*#`_~>]"), "")
            .replace(Regex("\\[(.*?)\\]\\(.*?\\)"), "$1")
            .trim()

        if (cleanText.isBlank()) return

        currentSpeakingText = cleanText
        currentMessageId = messageId

        val params = Bundle().apply {
            putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, messageId)
        }

        val res = tts?.speak(cleanText, TextToSpeech.QUEUE_FLUSH, params, messageId)
        if (res == TextToSpeech.ERROR) {
            _ttsState.value = TtsState.Error("Could not speak text")
        }
    }

    fun stop() {
        if (isInitialized) {
            tts?.stop()
        }
        _ttsState.value = TtsState.Idle
    }

    fun pause() {
        if (isInitialized && _ttsState.value is TtsState.Speaking) {
            tts?.stop()
            _ttsState.value = TtsState.Paused(currentMessageId)
        }
    }

    fun resume() {
        if (_ttsState.value is TtsState.Paused && currentSpeakingText.isNotBlank()) {
            speak(currentMessageId, currentSpeakingText)
        }
    }

    fun shutdown() {
        try {
            tts?.stop()
            tts?.shutdown()
            tts = null
        } catch (ignored: Exception) {}
    }
}
