package com.example.di

import android.content.Context
import androidx.room.Room
import com.example.data.local.AppDatabase
import com.example.data.repository.AuthRepository
import com.example.data.repository.BillingRepository
import com.example.data.repository.DocumentRepository
import com.example.data.repository.GeminiChatRepository
import com.example.data.repository.PhotoEditorRepository
import com.example.data.repository.UsageManager
import com.example.service.SpeechRecognitionHelper
import com.example.service.TextToSpeechHelper

class AppContainer(private val context: Context) {
    val database: AppDatabase by lazy {
        Room.databaseBuilder(
            context.applicationContext,
            AppDatabase::class.java,
            "noviq_ai_database"
        ).fallbackToDestructiveMigration(false).build()
    }

    val authRepository: AuthRepository by lazy {
        AuthRepository(context.applicationContext)
    }

    val billingRepository: BillingRepository by lazy {
        BillingRepository(context.applicationContext)
    }

    val usageManager: UsageManager by lazy {
        UsageManager(context.applicationContext, billingRepository)
    }

    val chatRepository: GeminiChatRepository by lazy {
        GeminiChatRepository(database.chatDao(), usageManager)
    }

    val photoEditorRepository: PhotoEditorRepository by lazy {
        PhotoEditorRepository(context.applicationContext)
    }

    val documentRepository: DocumentRepository by lazy {
        DocumentRepository(context.applicationContext, database.documentDao(), usageManager)
    }

    val speechHelper: SpeechRecognitionHelper by lazy {
        SpeechRecognitionHelper(context.applicationContext)
    }

    val ttsHelper: TextToSpeechHelper by lazy {
        TextToSpeechHelper(context.applicationContext)
    }
}
